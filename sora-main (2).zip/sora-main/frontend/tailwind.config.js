module.exports = {
    plugins: [
        require('tailwind-scrollbar-hide'),
    ],
};