import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import progress from "vite-plugin-progress"; // Import progress plugin

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    react(),
    tailwindcss(),
    progress({ format: '[:bar] :percent :etas' }) // Show a progress bar
  ],
});
