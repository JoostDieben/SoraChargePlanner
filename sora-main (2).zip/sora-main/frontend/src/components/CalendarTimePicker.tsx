import React, { useState, useEffect } from "react";
import axios from "axios";
import { format, addDays, addMinutes, isBefore } from "date-fns";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface CalendarTimePickerProps {
    onClose: () => void;
    orderId: string;
}

const durationOptions = [
    { label: "30 mins", value: 30 },
    { label: "1 hour", value: 60 },
    { label: "1.5 hours", value: 90 }
];

const CalendarTimePicker: React.FC<CalendarTimePickerProps> = ({ onClose, orderId }) => {
    console.log("Received OrderId in CalendarTimePicker:", orderId); // Debug log
    
    const [selectedDate, setSelectedDate] = useState<Date | null>(null);
    const [selectedTimeIndex, setSelectedTimeIndex] = useState<number | null>(null);
    const [selectedDuration, setSelectedDuration] = useState<number>(30);
    const [currentMonth, setCurrentMonth] = useState(new Date());
    const [availableDates, setAvailableDates] = useState<Record<string, string[]>>({});
    const [fleetManagerId, setFleetManagerId] = useState<number | null>(null);
    const today = new Date();
    const daysInMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0).getDate();
    const firstDayOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1).getDay();

    const generateAllAvailableSlots = () => {
        const slots: Record<string, string[]> = {};
        const startDate = new Date();
        const endDate = new Date(2026, 11, 31); // December 31, 2026
        
        // Standard working hours time slots (every 30 minutes)
        const dailyTimeSlots = [
            "08:00", "08:30", "09:00", "09:30", "10:00", "10:30",
            "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
            "14:00", "14:30", "15:00", "15:30", "16:00", "16:30"
        ];
    
        // Generate for each day
        let currentDate = new Date(startDate);
        while (currentDate <= endDate) {
            const dateKey = format(currentDate, "yyyy-MM-dd");
            
            // Skip weekends (Saturday and Sunday)
            const dayOfWeek = currentDate.getDay();
            if (dayOfWeek !== 0 && dayOfWeek !== 6) {
                slots[dateKey] = [...dailyTimeSlots];
            } else {
                // Reduced availability on weekends
                slots[dateKey] = [
                    "09:00", "09:30", "10:00", "10:30", 
                    "11:00", "11:30", "12:00", "13:00",
                    "13:30", "14:00", "14:30", "15:00"
                ];
            }
            
            currentDate = addDays(currentDate, 1);
        }
    
        return slots;
    };
    
    const mockAvailableSlots = generateAllAvailableSlots();

    useEffect(() => {
        setAvailableDates(mockAvailableSlots);
        const storedFleetManagerId = localStorage.getItem('userId');
        if (storedFleetManagerId) {
            setFleetManagerId(parseInt(storedFleetManagerId));
        }
    }, []);

    useEffect(() => {
        setSelectedTimeIndex(null);
    }, [selectedDate, selectedDuration]);

    const getAvailableTimes = (date: Date | null) => {
        if (!date) return [];
        const dateKey = format(date, "yyyy-MM-dd");
        return availableDates[dateKey] || [];
    };

    const getFilteredAvailableTimes = (date: Date | null) => {
        const times = getAvailableTimes(date);
        if (!date || times.length === 0) return [];

        return times.filter(time => {
            const [hours, minutes] = time.split(':').map(Number);
            const startDateTime = new Date(date);
            startDateTime.setHours(hours, minutes, 0, 0);
            
            const endDateTime = addMinutes(startDateTime, selectedDuration);
            
            if (endDateTime.getDate() !== date.getDate()) return false;
            
            const allTimes = getAvailableTimes(date);
            for (let i = 0; i < selectedDuration; i += 30) {
                const checkTime = addMinutes(startDateTime, i);
                const checkTimeStr = format(checkTime, "HH:mm");
                if (!allTimes.includes(checkTimeStr)) {
                    return false;
                }
            }
            
            return true;
        });
    };

    const handleDateClick = (day: number) => {
        const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
        if (isBefore(date, today) && format(date, "yyyy-MM-dd") !== format(today, "yyyy-MM-dd")) {
            return;
        }
        setSelectedDate(date);
    };

    const handlePrevMonth = () => {
        const prevMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1);
        if (isBefore(prevMonth, today) && format(prevMonth, "yyyy-MM") !== format(today, "yyyy-MM")) {
            return;
        }
        setCurrentMonth(prevMonth);
    };

    const handleNextMonth = () => {
        setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1));
    };

    const formatTimeWithAMPM = (time: string) => {
        const [hour, minute] = time.split(":").map(Number);
        const ampm = hour >= 12 ? "PM" : "AM";
        const formattedHour = hour % 12 || 12;
        return `${formattedHour}:${minute.toString().padStart(2, "0")} ${ampm}`;
    };

    const handleBookSlot = async () => {
        if (!selectedDate || selectedTimeIndex === null) {
            alert("Please select a date and time.");
            return;
        }
        if (!fleetManagerId) {
            alert("Fleet manager ID not found. Please log in again.");
            return;
        }
        if (!orderId) {
            alert("Order ID not found. Please try again.");
            return;
        }
    
        const availableTimes = getFilteredAvailableTimes(selectedDate);
        const selectedTime = availableTimes[selectedTimeIndex];
        
        const [hours, minutes] = selectedTime.split(':').map(Number);
        const startDateTime = new Date(selectedDate);
        startDateTime.setHours(hours, minutes, 0, 0);
        
        const endDateTime = addMinutes(startDateTime, selectedDuration);
        const durationInSeconds = selectedDuration * 60;
        
        const reservationData = {
            connector: "ce3ce49e-0322-11f0-8d80-02420a000043",
            duration: durationInSeconds,
            end_date_time: format(endDateTime, "yyyy-MM-dd HH:mm:ss"),
            start_date_time: format(startDateTime, "yyyy-MM-dd HH:mm:ss"),
            rate: 0,
            user: "ad94557e-08b3-11f0-a2de-02420a000059",
            fleetManagerId: fleetManagerId,
            OrderId: orderId,
            timezone: "Europe/Amsterdam"
        };
    
        try {
            const response = await axios.post("/api/reservations", reservationData);
            alert("Charge stop added successfully for order " + orderId);
            console.log(response.data);
            onClose();
        } catch (error) {
            console.error("Error booking slot:", error);
            alert("Failed to book slot. Please try again.");
        }
    };

    const renderCalendarDays = () => {
        const days = [];
        const todayStr = format(today, "yyyy-MM-dd");
        
        for (let i = 0; i < firstDayOfMonth; i++) {
            days.push(<div key={`empty-${i}`} className="p-1"></div>);
        }
        
        for (let i = 1; i <= daysInMonth; i++) {
            const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), i);
            const dateStr = format(date, "yyyy-MM-dd");
            const isPast = isBefore(date, today) && dateStr !== todayStr;
            const hasAvailability = getAvailableTimes(date).length > 0;
            
            days.push(
                <button
                    key={i}
                    onClick={() => !isPast && handleDateClick(i)}
                    disabled={isPast || !hasAvailability}
                    className={`p-2 rounded-md transition-all ${
                        isPast 
                            ? "text-gray-400 cursor-not-allowed"
                            : hasAvailability
                                ? selectedDate?.getDate() === i 
                                    ? "bg-blue-500 text-white font-bold"
                                    : "text-gray-800 hover:bg-gray-200"
                                : "text-gray-400 cursor-not-allowed"
                    }`}
                >
                    {i}
                </button>
            );
        }
        
        return days;
    };

    return (
        <div className="fixed inset-0 flex items-center justify-center bg-black/75">
            <div className="p-6 bg-white shadow-lg rounded-lg w-[700px] mx-auto">
                <h2 className="text-xl font-semibold mb-4">Add Charge Stop for Order: {orderId}</h2>

                <div className="flex justify-between border-b pb-2">
                    <button 
                        onClick={handlePrevMonth} 
                        className="text-gray-600 hover:text-black w-6"
                        disabled={format(currentMonth, "yyyy-MM") === format(today, "yyyy-MM")}
                    >
                        <ChevronLeft className="w-5 h-5" />
                    </button>
                    <span className="font-medium text-gray-800">
                        {format(currentMonth, "MMMM yyyy")}
                    </span>
                    <button onClick={handleNextMonth} className="text-gray-600 hover:text-black w-6">
                        <ChevronRight className="w-5 h-5" />
                    </button>
                </div>

                <div className="flex mt-4">
                    <div className="w-1/2 pr-4">
                        <div className="grid grid-cols-7 text-center text-sm font-semibold text-gray-700">
                            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                                <div key={day} className="p-1">{day}</div>
                            ))}
                        </div>
                        <div className="grid grid-cols-7 text-center text-sm">
                            {renderCalendarDays()}
                        </div>
                    </div>

                    <div className="w-1/2 pl-4 border-l">
                        <div className="mb-4">
                            <label className="block text-sm font-medium text-gray-700 mb-1">Duration</label>
                            <div className="flex gap-2">
                                {durationOptions.map((option) => (
                                    <button
                                        key={option.value}
                                        onClick={() => setSelectedDuration(option.value)}
                                        className={`px-3 py-1 rounded-md text-sm ${
                                            selectedDuration === option.value
                                                ? "bg-blue-500 text-white"
                                                : "bg-gray-200 text-gray-800 hover:bg-gray-300"
                                        }`}
                                    >
                                        {option.label}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Available Times</label>
                            <div className="max-h-60 overflow-y-auto border rounded-md p-2">
                                {selectedDate ? (
                                    getFilteredAvailableTimes(selectedDate).length > 0 ? (
                                        getFilteredAvailableTimes(selectedDate).map((time, index) => {
                                            const [hours, minutes] = time.split(':').map(Number);
                                            const startDateTime = new Date(selectedDate);
                                            startDateTime.setHours(hours, minutes, 0, 0);
                                            const endDateTime = addMinutes(startDateTime, selectedDuration);
                                            const endTimeStr = format(endDateTime, "HH:mm");
                                            
                                            return (
                                                <button
                                                    key={time}
                                                    onClick={() => setSelectedTimeIndex(index)}
                                                    className={`p-2 w-full my-1 rounded-md transition-all text-left ${
                                                        index === selectedTimeIndex
                                                            ? "bg-blue-500 text-white font-bold"
                                                            : "text-gray-800 hover:bg-gray-200"
                                                    }`}
                                                >
                                                    {formatTimeWithAMPM(time)} - {formatTimeWithAMPM(endTimeStr)}
                                                </button>
                                            );
                                        })
                                    ) : (
                                        <div className="text-center text-gray-500 py-4">
                                            No available slots for {format(selectedDate, "MMM d")} with {selectedDuration} minute duration
                                        </div>
                                    )
                                ) : (
                                    <div className="text-center text-gray-500 py-4">
                                        Select a date to see available times
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>

                <div className="flex justify-end gap-2 mt-4">
                    <button
                        className="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400"
                        onClick={onClose}
                    >
                        Cancel
                    </button>
                    <button
                        className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 disabled:opacity-50"
                        onClick={handleBookSlot}
                        disabled={!selectedDate || selectedTimeIndex === null}
                    >
                        Book Charge Stop
                    </button>
                </div>
            </div>
        </div>
    );
};

export default CalendarTimePicker;
