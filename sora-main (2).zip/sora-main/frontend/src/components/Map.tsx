import React, { useState } from "react";
import {
    GoogleMap,
    LoadScript,
    Autocomplete,
    Marker,
    Polyline,
    OverlayView,
} from "@react-google-maps/api";
import axios from "axios";
import type { Libraries } from "@react-google-maps/api";

const libraries: Libraries = ["places", "geometry"];
const mapContainerStyle = { width: "100%", height: "500px" };
const defaultCenter = { lat: 37.7749, lng: -122.4194 };

const Map: React.FC = () => {
    const [source, setSource] = useState<{ lat: number; lng: number } | null>(null);
    const [destination, setDestination] = useState<{ lat: number; lng: number } | null>(null);
    const [decodedPath, setDecodedPath] = useState<google.maps.LatLngLiteral[] | null>(null);
    const [mapCenter, setMapCenter] = useState(defaultCenter);
    const [isLoading, setIsLoading] = useState(false);
    const [truckChargingStations, setTruckChargingStations] = useState<google.maps.places.PlaceResult[]>([]);
    const [lowFuelCheckpoints, setLowFuelCheckpoints] = useState<{ location: google.maps.LatLngLiteral; type: "25%" | "15%" | "0%" }[]>([]);

    const [sourceAutocomplete, setSourceAutocomplete] = useState<google.maps.places.Autocomplete | null>(null);
    const [destinationAutocomplete, setDestinationAutocomplete] = useState<google.maps.places.Autocomplete | null>(null);

    const handleSourceLoad = (autocomplete: google.maps.places.Autocomplete) => setSourceAutocomplete(autocomplete);
    const handleDestinationLoad = (autocomplete: google.maps.places.Autocomplete) => setDestinationAutocomplete(autocomplete);

    const handlePlaceSelect = (type: "source" | "destination") => {
        const autocomplete = type === "source" ? sourceAutocomplete : destinationAutocomplete;
        if (!autocomplete) return;

        const place = autocomplete.getPlace();
        if (!place || !place.geometry || !place.geometry.location) return;

        const location = {
            lat: place.geometry.location.lat(),
            lng: place.geometry.location.lng(),
        };

        if (type === "source") {
            setSource(location);
            setMapCenter(location);
        } else {
            setDestination(location);
            setMapCenter(location);
        }

        setDecodedPath(null);
        setTruckChargingStations([]); // Clear charging stations when a new route is selected
        setLowFuelCheckpoints([]); // Clear low fuel checkpoints when a new route is selected
    };

    const calculateRoute = async (origin: { lat: number; lng: number }, destination: { lat: number; lng: number }) => {
        if (!origin || !destination) return;

        setIsLoading(true);

        const requestBody = {
            origin: {
                location: {
                    latLng: {
                        latitude: origin.lat,
                        longitude: origin.lng,
                    },
                },
            },
            destination: {
                location: {
                    latLng: {
                        latitude: destination.lat,
                        longitude: destination.lng,
                    },
                },
            },
            travelMode: "DRIVE",
        };

        try {
            const response = await axios.post(
                "https://routes.googleapis.com/directions/v2:computeRoutes",
                requestBody,
                {
                    headers: {
                        "Content-Type": "application/json",
                        "X-Goog-Api-Key": googleMapsApiKey,
                        "X-Goog-FieldMask": "routes.duration,routes.distanceMeters,routes.polyline.encodedPolyline",
                    },
                }
            );

            const route = response.data.routes[0];
            if (route) {
                const decodedPath = google.maps.geometry.encoding.decodePath(route.polyline.encodedPolyline);
                setDecodedPath(decodedPath);
                findTruckChargingStationsAlongRoute(decodedPath); // Find truck charging stations along the route

                // Calculate low fuel checkpoints only if the distance is 250 km or more
                if (route.distanceMeters / 1000 >= 250) {
                    calculateLowFuelCheckpoints(decodedPath, route.distanceMeters / 1000);
                } else {
                    setLowFuelCheckpoints([]); // Clear low fuel checkpoints for short distances
                }
            }
        } catch (error) {
            console.error("Error fetching route: ", error);
            alert("Failed to fetch route. Please check your API key and billing settings.");
        } finally {
            setIsLoading(false);
        }
    };

    const findTruckChargingStationsAlongRoute = (path: google.maps.LatLngLiteral[]) => {
        if (!path || path.length === 0) return;

        const placesService = new google.maps.places.PlacesService(document.createElement("div"));

        // Search for EV charging stations with keywords for trucks
        const requests = path.map((point) => {
            return new Promise<google.maps.places.PlaceResult[]>((resolve) => {
                placesService.nearbySearch(
                    {
                        location: point,
                        radius: 10,
                        keyword: "oyaya",
                    },
                    (results, status) => {
                        if (status === google.maps.places.PlacesServiceStatus.OK && results) {
                            resolve(results);
                        } else {
                            resolve([]);
                        }
                    }
                );
            });
        });

        // Combine results from all requests
        Promise.all(requests).then((results) => {
            const allChargingStations = results.flat();

            // Filter charging stations that are on or near the route line
            const truckChargingStationsOnRoute = allChargingStations.filter((station) => {
                const stationLocation = station.geometry?.location;
                if (!stationLocation) return false;

                // Convert station location to LatLngLiteral
                const stationLatLng = {
                    lat: stationLocation.lat(),
                    lng: stationLocation.lng(),
                };

                // Check if the station is on or near the route line (within 100 meters)
                return google.maps.geometry.poly.isLocationOnEdge(
                    stationLatLng,
                    new google.maps.Polyline({ path }),
                    100 // Tolerance in meters
                );
            });

            setTruckChargingStations(truckChargingStationsOnRoute);
        });
    };

    const calculateLowFuelCheckpoints = (path: google.maps.LatLngLiteral[], totalDistance: number) => {
        const mileageRange = 250; // Truck's mileage range in km
        const lowFuel25Percent = mileageRange * 0.75; // 25% low fuel (187.5 km)
        const lowFuel15Percent = mileageRange * 0.85; // 15% low fuel (212.5 km)
        const noFuel = mileageRange; // 0% fuel (250 km)

        let distanceCovered = 0;
        const lowFuelCheckpoints: { location: google.maps.LatLngLiteral; type: "25%" | "15%" | "0%" }[] = [];

        for (let i = 0; i < path.length - 1; i++) {
            const segmentDistance = google.maps.geometry.spherical.computeDistanceBetween(
                new google.maps.LatLng(path[i]),
                new google.maps.LatLng(path[i + 1])
            ) / 1000; // Convert meters to kilometers

            distanceCovered += segmentDistance;

            // Check for exact 25%, 15%, and 0% fuel points
            if (!lowFuelCheckpoints.some((checkpoint) => checkpoint.type === "25%") && distanceCovered >= lowFuel25Percent) {
                lowFuelCheckpoints.push({ location: path[i], type: "25%" });
            } else if (!lowFuelCheckpoints.some((checkpoint) => checkpoint.type === "15%") && distanceCovered >= lowFuel15Percent) {
                lowFuelCheckpoints.push({ location: path[i], type: "15%" });
            } else if (!lowFuelCheckpoints.some((checkpoint) => checkpoint.type === "0%") && distanceCovered >= noFuel) {
                lowFuelCheckpoints.push({ location: path[i], type: "0%" });
                break; // Stop after reaching 0% fuel
            }
        }

        setLowFuelCheckpoints(lowFuelCheckpoints);
    };

    const handleSubmit = () => {
        if (!source || !destination) {
            alert("Please select both source and destination.");
            return;
        }

        setDecodedPath(null);
        setTruckChargingStations([]); // Clear existing charging stations
        setLowFuelCheckpoints([]); // Clear existing low fuel checkpoints
        calculateRoute(source, destination);
    };

    const googleMapsApiKey = "YOUR_VALID_API_KEY";

    if (!googleMapsApiKey) {
        return <div>Error: Google Maps API key is missing.</div>;
    }

    return (
        <LoadScript googleMapsApiKey={googleMapsApiKey} libraries={libraries}>
            <div className="flex flex-col items-center gap-4 p-4">
                <form onSubmit={(e) => e.preventDefault()} className="flex flex-col md:flex-row gap-4 w-full max-w-2xl">
                    <Autocomplete onLoad={handleSourceLoad} onPlaceChanged={() => handlePlaceSelect("source")}>
                        <input type="text" placeholder="Enter Source" className="w-full p-2 border rounded-md shadow-sm" />
                    </Autocomplete>
                    <Autocomplete onLoad={handleDestinationLoad} onPlaceChanged={() => handlePlaceSelect("destination")}>
                        <input type="text" placeholder="Enter Destination" className="w-full p-2 border rounded-md shadow-sm" />
                    </Autocomplete>
                </form>
                <button
                    onClick={handleSubmit}
                    className="px-4 py-2 bg-blue-500 text-white rounded-md shadow-md hover:bg-blue-600"
                    disabled={isLoading}
                >
                    {isLoading ? "Calculating Route..." : "Submit Coordinates"}
                </button>
                {source && <p>Source Coordinates: {source.lat}, {source.lng}</p>}
                {destination && <p>Destination Coordinates: {destination.lat}, {destination.lng}</p>}
                <GoogleMap mapContainerStyle={mapContainerStyle} center={mapCenter} zoom={12}>
                    {source && <Marker position={source} />}
                    {destination && <Marker position={destination} />}

                    {/* Render the route */}
                    {decodedPath && (
                        <>
                            {/* If distance is less than 250 km, render a single green polyline */}
                            {lowFuelCheckpoints.length === 0 && (
                                <Polyline
                                    path={decodedPath}
                                    options={{ strokeColor: "green", strokeWeight: 5 }}
                                />
                            )}

                            {/* If distance is 250 km or more, render segmented polylines */}
                            {lowFuelCheckpoints.length > 0 && (
                                <>
                                    {/* Green: From Start to 25% Fuel Checkpoint */}
                                    <Polyline
                                        path={decodedPath.slice(0, decodedPath.indexOf(lowFuelCheckpoints.find(c => c.type === "25%")?.location || decodedPath[0]))}
                                        options={{ strokeColor: "green", strokeWeight: 5 }}
                                    />

                                    {/* Yellow: From 25% to 0% Fuel Checkpoint */}
                                    {lowFuelCheckpoints.some(c => c.type === "0%") && (
                                        <Polyline
                                            path={decodedPath.slice(
                                                decodedPath.indexOf(lowFuelCheckpoints.find(c => c.type === "25%")?.location || decodedPath[0]),
                                                decodedPath.indexOf(lowFuelCheckpoints.find(c => c.type === "0%")?.location || decodedPath[0])
                                            )}
                                            options={{ strokeColor: "yellow", strokeWeight: 5 }}
                                        />
                                    )}

                                    {/* Red: From 0% Fuel Checkpoint to Destination */}
                                    <Polyline
                                        path={decodedPath.slice(
                                            decodedPath.indexOf(lowFuelCheckpoints.find(c => c.type === "0%")?.location || decodedPath[0])
                                        )}
                                        options={{ strokeColor: "red", strokeWeight: 5 }}
                                    />
                                </>
                            )}
                        </>
                    )}

                    {/* Render charging stations */}
                    {truckChargingStations.map((station, index) => {
                        const stationLocation = {
                            lat: station.geometry?.location?.lat() || 0,
                            lng: station.geometry?.location?.lng() || 0,
                        };

                        return (
                            <Marker
                                key={index}
                                position={stationLocation}
                                icon={{
                                    url: "https://maps.google.com/mapfiles/kml/pal3/icon21.png", // Custom icon for fuel stations
                                    scaledSize: new google.maps.Size(32, 32),
                                }}
                            />
                        );
                    })}

                    {/* Render low fuel checkpoints */}
                    {lowFuelCheckpoints.map((checkpoint, index) => (
                        <React.Fragment key={index}>
                            <Marker
                                position={checkpoint.location}
                                icon={{
                                    url: checkpoint.type === "25%"
                                        ? "/images/truck.png"  // Truck icon for 25%
                                        : checkpoint.type === "15%"
                                            ? "/images/truck.png"  // Truck icon for 15%
                                            : "/images/truck.png",  // Truck icon for other cases
                                    scaledSize: new google.maps.Size(32, 32),
                                }}
                            />
                            <OverlayView
                                position={checkpoint.location}
                                mapPaneName={OverlayView.OVERLAY_MOUSE_TARGET}
                            >
                                <div style={{
                                    position: "absolute",
                                    bottom: "40px",  // Moves text above the marker
                                    left: "-10px",   // Centers text
                                    color: "red",
                                    fontWeight: "bold",
                                    background: "white",
                                    padding: "2px 5px",
                                    borderRadius: "5px",
                                    fontSize: "14px",
                                    textAlign: "center",
                                }}>
                                    {checkpoint.type}
                                </div>
                            </OverlayView>
                        </React.Fragment>
                    ))}
                </GoogleMap>
            </div>
        </LoadScript>
    );
};

export default Map;
