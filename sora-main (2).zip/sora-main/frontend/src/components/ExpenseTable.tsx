import React, { useState, useEffect } from "react";
import { Eye, Download, Plus, ChevronDown } from "lucide-react";
import { FaTimes } from "react-icons/fa";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

interface Transaction {
    id: string;
    date: string;
    duration: string;
    units: string;
    price: string;
    location: string;
    status: string;
    paymentMethod: string;
    kWhConsumed: number;
    costPerUnit: number;
}

const ExpenseDashboard: React.FC = () => {
    // State management
    const [currentPage, setCurrentPage] = useState(1);
    const [searchTerm, setSearchTerm] = useState("");
    const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
    const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
    const [selectedMonth, setSelectedMonth] = useState<number | null>(null);
    const [selectedYear, setSelectedYear] = useState<number | null>(null);
    const [isMonthDropdownOpen, setIsMonthDropdownOpen] = useState(false);
    const [isYearDropdownOpen, setIsYearDropdownOpen] = useState(false);

    // Set default to current month/year on component mount
    useEffect(() => {
        const currentDate = new Date();
        setSelectedMonth(currentDate.getMonth());
        setSelectedYear(currentDate.getFullYear());
    }, []);

    // Sample data
    const allTransactions: Transaction[] = [
        { id: "#227799", date: "2025-03-15", duration: "30 Min", units: "20K wh", price: "$2,000", location: "Station A", status: "Completed", paymentMethod: "Credit Card", kWhConsumed: 20000, costPerUnit: 0.10 },
        { id: "#227800", date: "2025-03-16", duration: "45 Min", units: "25K wh", price: "$2,500", location: "Station B", status: "Completed", paymentMethod: "Debit Card", kWhConsumed: 25000, costPerUnit: 0.10 },
        { id: "#227801", date: "2025-04-17", duration: "30 Min", units: "18K wh", price: "$1,800", location: "Station C", status: "Pending", paymentMethod: "Bank Transfer", kWhConsumed: 18000, costPerUnit: 0.10 },
        { id: "#227802", date: "2025-04-18", duration: "60 Min", units: "35K wh", price: "$3,500", location: "Station A", status: "Completed", paymentMethod: "Credit Card", kWhConsumed: 35000, costPerUnit: 0.10 },
        { id: "#227803", date: "2025-05-19", duration: "30 Min", units: "15K wh", price: "$1,500", location: "Station D", status: "Failed", paymentMethod: "Wallet", kWhConsumed: 15000, costPerUnit: 0.10 },
        { id: "#227804", date: "2025-05-20", duration: "40 Min", units: "22K wh", price: "$2,200", location: "Station B", status: "Completed", paymentMethod: "Debit Card", kWhConsumed: 22000, costPerUnit: 0.10 },
        { id: "#227805", date: "2025-06-21", duration: "30 Min", units: "19K wh", price: "$1,900", location: "Station E", status: "Completed", paymentMethod: "Credit Card", kWhConsumed: 19000, costPerUnit: 0.10 },
        { id: "#227806", date: "2025-06-22", duration: "33 Min", units: "21K wh", price: "$2,100", location: "Station A", status: "Completed", paymentMethod: "Bank Transfer", kWhConsumed: 21000, costPerUnit: 0.10 },
        { id: "#227807", date: "2025-07-23", duration: "30 Min", units: "17K wh", price: "$1,700", location: "Station C", status: "Pending", paymentMethod: "Wallet", kWhConsumed: 17000, costPerUnit: 0.10 },
        { id: "#227808", date: "2025-07-24", duration: "60 Min", units: "30K wh", price: "$3,000", location: "Station B", status: "Completed", paymentMethod: "Credit Card", kWhConsumed: 30000, costPerUnit: 0.10 },
    ];

    // Month and year options with "All" option
    const months = [
        { value: null, label: "All Months" },
        { value: 0, label: "January" }, { value: 1, label: "February" }, { value: 2, label: "March" },
        { value: 3, label: "April" }, { value: 4, label: "May" }, { value: 5, label: "June" },
        { value: 6, label: "July" }, { value: 7, label: "August" }, { value: 8, label: "September" },
        { value: 9, label: "October" }, { value: 10, label: "November" }, { value: 11, label: "December" }
    ];

    const years = [
        { value: null, label: "All Years" },
        { value: 2023, label: "2023" },
        { value: 2024, label: "2024" },
        { value: 2025, label: "2025" },
        { value: 2026, label: "2026" }
    ];

    // Filter transactions by selected month and year (or show all if null)
    const filteredByDate = allTransactions.filter(tx => {
        const txDate = new Date(tx.date);
        const monthMatch = selectedMonth === null || txDate.getMonth() === selectedMonth;
        const yearMatch = selectedYear === null || txDate.getFullYear() === selectedYear;
        return monthMatch && yearMatch;
    });

    // Calculate totals
    const totalBillAmount = filteredByDate.reduce(
        (sum, tx) => sum + parseFloat(tx.price.replace(/[^0-9.-]+/g, "")), 0
    );
    const totalUnitsConsumed = filteredByDate.reduce(
        (sum, tx) => sum + tx.kWhConsumed, 0
    );

    // Search functionality
    const filteredTransactions = filteredByDate.filter((tx) =>
        Object.values(tx).some((value) =>
            String(value).toLowerCase().includes(searchTerm.toLowerCase())
        )
    );

    // Pagination
    const rowsPerPage = 10;
    const totalPages = Math.ceil(filteredTransactions.length / rowsPerPage);
    const startIndex = (currentPage - 1) * rowsPerPage;
    const currentTransactions = filteredTransactions.slice(startIndex, startIndex + rowsPerPage);

    // Get current selected month/year labels
    const selectedMonthLabel = selectedMonth === null
        ? "All Months"
        : months.find(m => m.value === selectedMonth)?.label || "All Months";

    const selectedYearLabel = selectedYear === null
        ? "All Years"
        : years.find(y => y.value === selectedYear)?.label || "All Years";

    // Helper functions
    const handleViewDetails = (tx: Transaction) => {
        setSelectedTransaction(tx);
        setIsDetailsModalOpen(true);
    };

    const closeDetailsModal = () => {
        setIsDetailsModalOpen(false);
        setSelectedTransaction(null);
    };

    const formatCurrency = (amount: number) => {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(amount);
    };

    const formatNumber = (num: number) => {
        return new Intl.NumberFormat('en-US').format(num);
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-lg">
            <ToastContainer position="top-center" autoClose={3000} />

            <h1 className="text-2xl font-bold mb-6 text-gray-800">Charge Expense</h1>
            {/* Header with controls */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
                {/* Left side controls - Year/Month dropdowns and totals */}
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                    {/* Year/Month dropdowns */}
                    <div className="flex items-center gap-2 h-10">
                        <div className="relative h-full">
                            <button
                                onClick={() => setIsMonthDropdownOpen(!isMonthDropdownOpen)}
                                className="flex items-center justify-between border rounded-md px-3 h-full bg-white shadow-sm w-32 hover:bg-gray-50 transition-colors"
                            >
                                <span className="text-sm truncate">{selectedMonthLabel}</span>
                                <ChevronDown className="w-4 h-4 flex-shrink-0" />
                            </button>
                            {isMonthDropdownOpen && (
                                <div className="absolute z-10 mt-1 w-32 bg-white border rounded-md shadow-lg max-h-60 overflow-auto">
                                    {months.map((month) => (
                                        <div
                                            key={month.value ?? "all"}
                                            className={`px-3 py-2 text-sm hover:bg-gray-100 cursor-pointer ${selectedMonth === month.value ? 'bg-gray-100' : ''}`}
                                            onClick={() => {
                                                setSelectedMonth(month.value);
                                                setIsMonthDropdownOpen(false);
                                                setCurrentPage(1);
                                            }}
                                        >
                                            {month.label}
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>

                        <div className="relative h-full">
                            <button
                                onClick={() => setIsYearDropdownOpen(!isYearDropdownOpen)}
                                className="flex items-center justify-between border rounded-md px-3 h-full bg-white shadow-sm w-24 hover:bg-gray-50 transition-colors"
                            >
                                <span className="text-sm truncate">{selectedYearLabel}</span>
                                <ChevronDown className="w-4 h-4 flex-shrink-0" />
                            </button>
                            {isYearDropdownOpen && (
                                <div className="absolute z-10 mt-1 w-24 bg-white border rounded-md shadow-lg max-h-60 overflow-auto">
                                    {years.map((year) => (
                                        <div
                                            key={year.value ?? "all"}
                                            className={`px-3 py-2 text-sm hover:bg-gray-100 cursor-pointer ${selectedYear === year.value ? 'bg-gray-100' : ''}`}
                                            onClick={() => {
                                                setSelectedYear(year.value);
                                                setIsYearDropdownOpen(false);
                                                setCurrentPage(1);
                                            }}
                                        >
                                            {year.label}
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Totals */}
                    <div className="flex items-center gap-2 h-10">
                        <div className="border rounded-md px-3 h-full flex items-center bg-gray-50 min-w-[120px]">
                            <span className="text-sm mr-1 text-gray-600">Units:</span>
                            <span className="text-sm font-medium">{formatNumber(totalUnitsConsumed)}</span>
                        </div>
                        <div className="border rounded-md px-3 h-full flex items-center bg-gray-50 min-w-[120px]">
                            <span className="text-sm mr-1 text-gray-600">Bill:</span>
                            <span className="text-sm font-medium">{formatCurrency(totalBillAmount)}</span>
                        </div>
                    </div>
                </div>

                {/* Right side controls - Search and Add button */}
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 h-10 w-full md:w-auto">
                    {/* Search */}
                    <div className="w-full sm:min-w-[200px] h-full">
                        <input
                            type="text"
                            placeholder="Search transactions..."
                            className="w-full h-full border rounded-md px-3 text-sm focus:outline-none focus:ring-1 focus:ring-gray-300 hover:border-gray-400 transition-colors"
                            value={searchTerm}
                            onChange={(e) => {
                                setSearchTerm(e.target.value);
                                setCurrentPage(1);
                            }}
                        />
                    </div>

                    {/* Dowmload */}
                    <button
                        className="bg-black text-white px-4 h-full rounded-md flex items-center gap-2 whitespace-nowrap text-sm hover:bg-gray-800 transition-colors w-full sm:w-auto justify-center"
                    >
                        <Download size={16} />
                        <span>Download</span>
                    </button>
                </div>
            </div>

            {/* Transactions Table */}
            <div className="overflow-x-auto">
                <table className="w-full border border-gray-200 rounded-md overflow-hidden">
                    <thead>
                        <tr className="bg-gray-300 text-gray-700">
                            <th className="p-3 text-left text-sm">Transaction ID</th>
                            <th className="p-3 text-left text-sm">Date</th>
                            <th className="p-3 text-left text-sm">Duration</th>
                            <th className="p-3 text-left text-sm">Units</th>
                            <th className="p-3 text-left text-sm">Price</th>
                            <th className="p-3 text-left text-sm">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {currentTransactions.length > 0 ? (
                            currentTransactions.map((tx, index) => (
                                <tr key={index} className="even:bg-gray-100 odd:bg-gray-50 hover:bg-gray-200 transition-colors">
                                    <td className="p-3 text-blue-500 cursor-pointer hover:underline text-sm">
                                        {tx.id}
                                    </td>
                                    <td className="p-3 text-sm">{new Date(tx.date).toLocaleDateString()}</td>
                                    <td className="p-3 text-sm">{tx.duration}</td>
                                    <td className="p-3 text-sm">{tx.units}</td>
                                    <td className="p-3 text-sm">{tx.price}</td>
                                    <td className="p-3 text-sm flex gap-2">
                                        <button
                                            onClick={() => handleViewDetails(tx)}
                                            className="text-gray-600 hover:text-black transition-colors"
                                        >
                                            <Eye className="w-4 h-4" />
                                        </button>
                                        <button

                                            className="text-gray-600 hover:text-black transition-colors"
                                            title="Download"
                                        >
                                            <Download className="w-4 h-4" />
                                        </button>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan={6} className="text-center p-4 text-gray-500 text-sm">
                                    {filteredByDate.length === 0
                                        ? `No transactions found${selectedMonth !== null || selectedYear !== null ? ` for ${selectedMonthLabel} ${selectedYearLabel}` : ''}`
                                        : "No transactions match your search"}
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>

            {/* Pagination */}
            {filteredTransactions.length > 0 && (
                <div className="flex justify-between items-center mt-4">
                    <button
                        className={`px-4 py-2 bg-gray-200 rounded-md text-sm ${currentPage === 1 ? "bg-gray-100 text-gray-500 cursor-not-allowed" : "hover:bg-gray-300"}`}
                        disabled={currentPage === 1}
                        onClick={() => setCurrentPage(currentPage - 1)}
                    >
                        Previous
                    </button>
                    <span className="text-gray-700 text-sm">Page {currentPage} of {totalPages}</span>
                    <button
                        className={`px-4 py-2 bg-gray-200 rounded-md text-sm ${currentPage === totalPages ? "bg-gray-100 text-gray-500 cursor-not-allowed" : "hover:bg-gray-300"}`}
                        disabled={currentPage === totalPages}
                        onClick={() => setCurrentPage(currentPage + 1)}
                    >
                        Next
                    </button>
                </div>
            )}

            {/* Transaction Details Modal */}
            {isDetailsModalOpen && selectedTransaction && (
                <div className="fixed inset-0 bg-black/65 bg-opacity-50 flex justify-center items-center p-4 z-50">
                    <div className="bg-white p-6 rounded-lg shadow-lg max-w-[90%] md:max-w-[50%] w-full relative max-h-[90vh] overflow-y-auto">
                        <button
                            onClick={closeDetailsModal}
                            className="absolute top-4 right-4 text-gray-500 hover:text-gray-700 transition-colors"
                        >
                            <FaTimes size={20} />
                        </button>
                        <h3 className="text-xl font-semibold mb-4 text-center">Transaction Details</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                            <p><strong className="text-gray-600">Transaction ID:</strong> {selectedTransaction.id}</p>
                            <p><strong className="text-gray-600">Date:</strong> {new Date(selectedTransaction.date).toLocaleDateString()}</p>
                            <p><strong className="text-gray-600">Duration:</strong> {selectedTransaction.duration}</p>
                            <p><strong className="text-gray-600">Units:</strong> {selectedTransaction.units}</p>
                            <p><strong className="text-gray-600">Price:</strong> {selectedTransaction.price}</p>
                            <p><strong className="text-gray-600">kWh Consumed:</strong> {formatNumber(selectedTransaction.kWhConsumed)}</p>
                            <p><strong className="text-gray-600">Cost per Unit:</strong> ${selectedTransaction.costPerUnit.toFixed(2)}</p>
                            <p><strong className="text-gray-600">Location:</strong> {selectedTransaction.location}</p>
                            <p><strong className="text-gray-600">Status:</strong>
                                <span className={`ml-1 px-2 py-1 rounded-full text-xs ${selectedTransaction.status === "Completed" ? "bg-green-100 text-green-800" :
                                    selectedTransaction.status === "Pending" ? "bg-yellow-100 text-yellow-800" :
                                        "bg-red-100 text-red-800"
                                    }`}>
                                    {selectedTransaction.status}
                                </span>
                            </p>
                            <p><strong className="text-gray-600">Payment Method:</strong> {selectedTransaction.paymentMethod}</p>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ExpenseDashboard;