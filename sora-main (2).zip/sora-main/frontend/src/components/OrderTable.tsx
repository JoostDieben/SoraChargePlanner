import React, { useState, useEffect } from "react";
import { FaEdit, FaTimes } from "react-icons/fa";
import { Plus } from "lucide-react";
import OrderFormModal from "./OrderFormModal";
import Timeline from "./Timeline";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";


interface Order {
    OrderId: string;
    name: string;
    quantity: number;
    route: string;
    startLocation: string;
    endLocation: string;
    customer: string;
    items: string;
    weight: string;
    startDateTime: string;
    endDateTime: string;
    tripType: string;
    type: string;
    operatingDays: string;
}

interface Reservation {
    id: string;
    fleetManagerId: number;
    OrderId: string;
    connector: string;
    charger: string;
    duration: number;
    start_date_time: Date;
    end_date_time: Date;
    rate: number;
    source_id: string;
    status: string;
    ocpp_reservation_id: string;
    id_token: string;
    created_at: Date;
    updated_at: Date;
    expiry_datetime: Date;
    timezone: string;
}

interface OrdersTableProps {
    orders: Order[];
    onSave: (order: Order) => void;
}

const OrdersTable: React.FC<OrdersTableProps> = ({ orders, onSave }) => {
    const rowsPerPage = 10;
    const [currentPage, setCurrentPage] = useState(1);
    const [selectedRoute, setSelectedRoute] = useState<string | null>(null);
    const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [searchTerm, setSearchTerm] = useState("");
    const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
    const [isEditing, setIsEditing] = useState(false);
    const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);

    const totalPages = Math.ceil(orders.length / rowsPerPage);
    const startIndex = (currentPage - 1) * rowsPerPage;
    const [reservations, setReservations] = useState<Reservation[]>([]);
    const [isLoadingReservations, setIsLoadingReservations] = useState(false);

    const formatDate = (date: Date | string) => {
        if (!date) return 'N/A';
        const d = new Date(date);
        return isNaN(d.getTime()) ? 'Invalid Date' : d.toLocaleString();
    };

    const fetchReservations = async (OrderId: string) => {
        setIsLoadingReservations(true);
        try {
            const response = await fetch(`/api/reservations/${OrderId}`);
            
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
            }
    
            const data = await response.json();
            console.log('Raw response data:', data);
    
            let reservationsData = [];
            if (Array.isArray(data)) {
                reservationsData = data;
            } else if (data && typeof data === 'object') {
                reservationsData = [data];
            }
    
            const processedReservations = reservationsData.map(res => ({
                ...res,
                start_date_time: new Date(res.start_date_time),
                end_date_time: new Date(res.end_date_time),
                created_at: new Date(res.created_at),
                updated_at: new Date(res.updated_at),
                expiry_datetime: new Date(res.expiry_datetime)
            }));
    
            setReservations(processedReservations);
        } catch (error) {
            console.error("Detailed fetch error:", error);
            console.error(`Failed to load reservations: ${error instanceof Error ? error.message : 'Unknown error'}`);
            setReservations([]);
        } finally {
            setIsLoadingReservations(false);
        }
    };
    
    const generateNewOrderId = () => `ORD-${Date.now()}`;

    const handleEditOrder = (order: Order) => {
        setSelectedOrder(order);
        setIsEditing(true);
        setIsModalOpen(true);
    };

    const handleRepeatOrder = (order: Order) => {
        const newOrder = {
            ...order,
            OrderId: generateNewOrderId(),
            startDateTime: "",
            endDateTime: "",
        };
        setSelectedOrder(newOrder);
        setIsEditing(false);
        setIsModalOpen(true);
    };

    const handleSaveOrder = (newOrder: Order) => {
        console.log("Order saved:", newOrder);
        onSave(newOrder);
        setIsModalOpen(false);
        toast.success("Order saved successfully!");
    };

    const filteredOrders = orders.filter((order) =>
        searchTerm
            ? Object.values(order).some((value) =>
                  value.toString().toLowerCase().includes(searchTerm.toLowerCase())
              )
            : true
    );

    const currentOrders = filteredOrders.slice(startIndex, startIndex + rowsPerPage);

    const handleViewDetails = async (order: Order) => {
        setSelectedOrder(order);
        setIsDetailsModalOpen(true);
        await fetchReservations(order.OrderId);
    };
    
    const closeDetailsModal = () => {
        setIsDetailsModalOpen(false);
        setSelectedOrder(null);
    };

    if (selectedRoute) {
        return (
            <div className="bg-white p-6 rounded-lg shadow-lg">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-semibold">Route Details: {selectedRoute}</h2>
                    {selectedOrderId && <p className="text-gray-700">Order ID: {selectedOrderId}</p>}
                    <button
                        className="bg-black text-white px-4 py-2 rounded-md"
                        onClick={() => {
                            setSelectedRoute(null);
                            setSelectedOrderId(null);
                        }}
                    >
                        Go Back
                    </button>
                </div>
                <Timeline selectedRoute={selectedRoute} orderId={selectedOrderId || ''} />
            </div>
        );
    }

    return (
        <div className="bg-white p-6 rounded-lg shadow-lg">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-semibold">Orders</h2>
                <div className="flex items-center justify-end space-x-2">
                    <input
                        type="text"
                        placeholder="Search"
                        className="border p-2 rounded-md w-1/2"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                    <button
                        onClick={() => {
                            setIsModalOpen(true);
                            setIsEditing(false);
                            setSelectedOrder(null);
                        }}
                        className="bg-black text-white px-4 py-2 rounded-md flex items-center space-x-2"
                    >
                        <Plus size={16} />
                        <span>Add Order</span>
                    </button>
                </div>
            </div>

            <h2 className="text-xl font-semibold mb-4">Invoices</h2>
            <table className="w-full">
                <thead>
                    <tr className="bg-gray-300">
                        <th className="p-2 text-left">Order ID</th>
                        <th className="p-2 text-left">Type</th>
                        <th className="p-2 text-left">Route ID</th>
                        <th className="p-2 text-left">Trip Type</th>
                        <th className="p-2 text-left">Customer</th>
                        <th className="p-2 text-left">Weight</th>
                        <th className="p-2 text-left">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {currentOrders.map((order) => (
                        <tr key={order.OrderId} className="even:bg-gray-100 odd:bg-gray-50 hover:bg-gray-200">
                            <td className="p-3 text-blue-500 cursor-pointer hover:underline" onClick={() => handleViewDetails(order)}>
                                #{order.OrderId}
                            </td>
                            <td className="p-2">{order.type}</td>
                            <td
                                className="p-2 text-blue-500 underline cursor-pointer"
                                onClick={() => {
                                    setSelectedRoute(order.route);
                                    setSelectedOrderId(order.OrderId);
                                }}
                            >
                                {order.route}
                            </td>
                            <td className="p-2">{order.tripType}</td>
                            <td className="p-2">{order.customer}</td>
                            <td className="p-2">{order.weight}</td>
                            <td className="p-2 flex space-x-4">
                                <button className="text-blue-500 hover:text-blue-700" onClick={() => handleEditOrder(order)}>
                                    <FaEdit />
                                </button>
                                <button className="text-green-500 hover:text-green-700" onClick={() => handleRepeatOrder(order)}>
                                    Repeat Order
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>

            <div className="flex justify-between items-center mt-4">
                <button
                    className={`px-4 py-2 bg-gray-200 rounded-md ${currentPage === 1 ? "bg-gray-100 text-gray-500 cursor-not-allowed" : "hover:bg-gray-300"}`}
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage(currentPage - 1)}
                >
                    Previous
                </button>
                <span className="text-gray-700">
                    Page {currentPage} of {totalPages}
                </span>
                <button
                    className={`px-4 py-2 bg-gray-200 rounded-md ${currentPage === totalPages ? "bg-gray-100 text-gray-500 cursor-not-allowed" : "hover:bg-gray-300"}`}
                    disabled={currentPage === totalPages}
                    onClick={() => setCurrentPage(currentPage + 1)}
                >
                    Next
                </button>
            </div>

            <OrderFormModal
                isOpen={isModalOpen}
                onClose={() => {
                    setIsModalOpen(false);
                    setSelectedOrder(null);
                    setIsEditing(false);
                }}
                onSave={handleSaveOrder}
                order={selectedOrder}
                isEditing={isEditing}
            />

            {isDetailsModalOpen && selectedOrder && (
                <div className="fixed inset-0 bg-black/65 flex justify-center items-center p-4">
                    <div className="bg-white p-6 rounded-lg shadow-lg max-w-[50%] w-full max-h-[90vh] overflow-y-auto relative">
                        <button onClick={closeDetailsModal} className="absolute top-4 right-4 text-gray-500 hover:text-gray-700">
                            <FaTimes size={20} />
                        </button>
                        <h3 className="text-2xl font-semibold mb-4 text-center">Order Details</h3>
                        <div className="grid grid-cols-2 gap-4 text-gray-700">
                            <p><strong>ID:</strong> {selectedOrder.OrderId}</p>
                            <p><strong>Name:</strong> {selectedOrder.name}</p>
                            <p><strong>Quantity:</strong> {selectedOrder.quantity}</p>
                            <p><strong>Route:</strong> {selectedOrder.route}</p>
                            <p><strong>Start Location:</strong> {selectedOrder.startLocation}</p>
                            <p><strong>End Location:</strong> {selectedOrder.endLocation}</p>
                            <p><strong>Customer:</strong> {selectedOrder.customer}</p>
                            <p><strong>Items:</strong> {selectedOrder.items}</p>
                            <p><strong>Weight:</strong> {selectedOrder.weight}</p>
                            <p><strong>Start Date:</strong> {selectedOrder.startDateTime}</p>
                            <p><strong>End Date:</strong> {selectedOrder.endDateTime}</p>
                            <p><strong>Trip Type:</strong> {selectedOrder.tripType}</p>
                            <p><strong>Type:</strong> {selectedOrder.type}</p>
                            <p><strong>Operating Days:</strong> {selectedOrder.operatingDays}</p>
                        </div>
                        
                        <div className="mt-6">
                            <h4 className="text-xl font-semibold mb-3">Reservations</h4>
                            {isLoadingReservations ? (
                                <div className="flex justify-center items-center py-4">
                                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
                                </div>
                            ) : reservations.length > 0 ? (
                                <div className="space-y-6">
                                    {reservations.map((reservation) => (
                                        <div key={reservation.id} className="border rounded-lg p-4 shadow-sm">
                                            <div className="grid grid-cols-2 gap-4">
                                                <div><strong>Reservation ID:</strong> {reservation.id}</div>
                                                <div><strong>Fleet Manager ID:</strong> {reservation.fleetManagerId}</div>
                                                <div><strong>Connector:</strong> {reservation.connector}</div>
                                                <div><strong>Charger:</strong> {reservation.charger}</div>
                                                <div><strong>Duration:</strong> {reservation.duration}</div>
                                                <div><strong>Start Time:</strong> {formatDate(reservation.start_date_time)}</div>
                                                <div><strong>End Time:</strong> {formatDate(reservation.end_date_time)}</div>
                                                <div><strong>Rate:</strong> {reservation.rate}</div>
                                                <div><strong>Source ID:</strong> {reservation.source_id}</div>
                                                <div>
                                                    <strong>Status:</strong> 
                                                    <span className={`ml-2 px-2 py-1 rounded-full text-xs ${
                                                        reservation.status === 'active' ? 'bg-green-100 text-green-800' :
                                                        reservation.status === 'expired' ? 'bg-yellow-100 text-yellow-800' :
                                                        reservation.status === 'cancelled' ? 'bg-red-100 text-red-800' :
                                                        'bg-gray-100 text-gray-800'
                                                    }`}>
                                                        {reservation.status}
                                                    </span>
                                                </div>
                                                <div><strong>OCPP Reservation ID:</strong> {reservation.ocpp_reservation_id}</div>
                                                <div><strong>ID Token:</strong> {reservation.id_token}</div>
                                                <div><strong>Created At:</strong> {formatDate(reservation.created_at)}</div>
                                                <div><strong>Updated At:</strong> {formatDate(reservation.updated_at)}</div>
                                                <div><strong>Expiry Time:</strong> {formatDate(reservation.expiry_datetime)}</div>
                                                <div><strong>Timezone:</strong> {reservation.timezone}</div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <div className="text-center py-4 text-gray-500">
                                    No reservations found for this order.
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}

            <ToastContainer position="top-center" autoClose={3000} />
        </div>
    );
};

export default OrdersTable;
