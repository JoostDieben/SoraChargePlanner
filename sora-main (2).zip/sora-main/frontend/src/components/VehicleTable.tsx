import React, { useState, useEffect } from "react";
import { FaEdit, FaTrash, FaTimes } from "react-icons/fa";
import { Plus } from "lucide-react";
import VehicleFormModal from "./VehicleFormModal";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";


interface Vehicle {
    vehicleId: number;
    vehicleName: string;
    date: string;
    vehicleNo: string;
    vin: string;
    batteryCapacity: string;
    dryRange: string;
    cRate: string;
    chassisNumber: string;
    model: string;
    year: number;
    vehicleType: string;
    manufacturer: string;
    ownerName: string;
    ownerContact: string;
    registrationDate: string;
    insuranceExpiry: string;
    vehiclePhoto: string;
    vehicleDocument: string;
}



const VehicleTable: React.FC = () => {
    const [vehicles, setVehicles] = useState<Vehicle[]>([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [searchTerm, setSearchTerm] = useState("");
    const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isEditing, setIsEditing] = useState(false);
    const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);

    const rowsPerPage = 10;
    const totalPages = Math.ceil(vehicles.length / rowsPerPage);
    const startIndex = (currentPage - 1) * rowsPerPage;

    const filteredVehicles = vehicles.filter((vehicle) =>
        Object.values(vehicle).some((value) =>
            String(value).toLowerCase().includes(searchTerm.toLowerCase())
    ));
const handleDeleteVehicle = async (vehicleId: number) => {
    if (!window.confirm("Are you sure you want to delete this Vehicle?")) return;

    try {
        const response = await fetch(`/api/vehicles/${vehicleId}`, {
            method: "DELETE",
        });

        if (response.ok) {
            toast.success("Vehicle deleted successfully!");
            refreshVehicles(); // Refresh the list after deletion
        } else {
            toast.error("Failed to delete vehicle.");
        }
    } catch (error) {
        console.error("Error deleting Vehicle:", error);
        toast.error("An error occurred while deleting the Vehicle.");
    }
};

    const currentVehicles = filteredVehicles.slice(startIndex, startIndex + rowsPerPage);

    // Fetch vehicles on component mount
    useEffect(() => {
        refreshVehicles();
    }, []);

    const refreshVehicles = async () => {
        try {
            const response = await fetch("/api/vehicles");
            const data = await response.json();
            if (response.ok) {
                setVehicles(data.vehicles);
            } else {
                toast.error("Error refreshing vehicles: " + data.message);
            }
        } catch (error) {
            toast.error("Error refreshing vehicles: " + error);
        }
    };

    const onVehicleAdded = (newVehicle: Vehicle) => {
        setVehicles(prevVehicles => [...prevVehicles, newVehicle]);
    };

    const closeModal = () => {
        setSelectedVehicle(null);
        setIsModalOpen(false);
        setIsEditing(false);
    };

    const handleEdit = (vehicle: Vehicle) => {
        setSelectedVehicle(vehicle);
        setIsEditing(true);
        setIsModalOpen(true);
    };

    const handleAddNew = () => {
        setSelectedVehicle(null);
        setIsEditing(false);
        setIsModalOpen(true);
    };

    // Update the VehicleTable's save handler to conditionally refresh
    const handleSaveSuccess = () => {
        refreshVehicles(); // Always fetch updated data from the backend
        setIsModalOpen(false);
        toast.success(isEditing ? "Vehicle updated successfully!" : "Vehicle added successfully!");
    };

    const handleViewDetails = (vehicle: Vehicle) => {
        setSelectedVehicle(vehicle);
        setIsDetailsModalOpen(true);
    };

    const closeDetailsModal = () => {
        setIsDetailsModalOpen(false);
        setSelectedVehicle(null);
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-lg">
            <ToastContainer position="top-center" autoClose={3000} />
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-semibold">Vehicles</h2>
                <div className="flex items-center justify-end space-x-2">
                    <input
                        type="text"
                        placeholder="Search"
                        className="border p-2 rounded-md w-1/2"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                    <button
                        onClick={handleAddNew}
                        className="bg-black text-white px-4 py-2 rounded-md flex items-center space-x-2"
                    >
                        <Plus size={16} />
                        <span>Add Vehicle</span>
                    </button>
                </div>
            </div>

            <table className="w-full border border-gray-200 rounded-md overflow-hidden">
                <thead>
                    <tr className="bg-gray-300 text-gray-700">
                        <th className="p-3 text-left">Vehicle ID</th>
                        <th className="p-3 text-left">Vehicle Name</th>
                        <th className="p-3 text-left">Vehicle No.</th>
                        <th className="p-3 text-left">Model</th>
                        <th className="p-3 text-left">Year</th>
                        <th className="p-3 text-left">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {currentVehicles.length > 0 ? (
                        currentVehicles.map((vehicle) => (
                            <tr key={vehicle.vehicleId} className="even:bg-gray-100 odd:bg-gray-50 hover:bg-gray-200 transition-all">
                                <td
                                    className="p-3 text-blue-500 cursor-pointer hover:underline"
                                    onClick={() => handleViewDetails(vehicle)}
                                >
                                    #{vehicle.vehicleId}
                                </td>
                                <td className="p-3">{vehicle.vehicleName}</td>
                                <td className="p-3">{vehicle.vehicleNo}</td>
                                <td className="p-3">{vehicle.model}</td>
                                <td className="p-3">{vehicle.year}</td>
                                <td className="p-3 flex space-x-4">
                                    <button
                                        className="text-blue-500 hover:text-blue-700"
                                        onClick={() => handleEdit(vehicle)}
                                    >
                                        <FaEdit />
                                    </button>
                                   <button
    className="text-red-500 hover:text-red-700"
    onClick={() => handleDeleteVehicle(vehicle.vehicleId)}
>
    <FaTrash />
</button>

                                </td>
                            </tr>
                        ))
                    ) : (
                        <tr>
                            <td colSpan={6} className="text-center p-4 text-gray-500">
                                No vehicles found.
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>

            <div className="flex justify-between items-center mt-4">
                <button
                    className={`px-4 py-2 bg-gray-200 rounded-md ${currentPage === 1 ? "bg-gray-100 text-gray-500 cursor-not-allowed" : "hover:bg-gray-300"}`}
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage(currentPage - 1)}
                >
                    Previous
                </button>
                <span className="text-gray-700">Page {currentPage} of {totalPages}</span>
                <button
                    className={`px-4 py-2 bg-gray-200 rounded-md ${currentPage === totalPages ? "bg-gray-100 text-gray-500 cursor-not-allowed" : "hover:bg-gray-300"}`}
                    disabled={currentPage === totalPages}
                    onClick={() => setCurrentPage(currentPage + 1)}
                >
                    Next
                </button>
            </div>

            <VehicleFormModal
                isOpen={isModalOpen}
                onClose={closeModal}
                onSave={handleSaveSuccess}
                existingVehicle={selectedVehicle || undefined}
                isEditing={isEditing}
            />

            {isDetailsModalOpen && selectedVehicle && (
                <div className="fixed inset-0 bg-black/65 bg-opacity-50 flex justify-center items-center p-4">
                    <div className="bg-white p-6 rounded-lg shadow-lg max-w-[50%] w-full relative">
                        <button onClick={closeDetailsModal} className="absolute top-4 right-4 text-gray-500 hover:text-gray-700">
                            <FaTimes size={20} />
                        </button>
                        <h3 className="text-2xl font-semibold mb-4 text-center">Vehicle Details</h3>
                        {selectedVehicle.vehiclePhoto ? (
                            <img
                                src={selectedVehicle.vehiclePhoto}
                                alt="Vehicle"
                                className="w-32 h-32 object-cover rounded-full mx-auto mb-4"
                            />
                        ) : (
                            <p className="text-center text-gray-500 mb-4">No Image Available</p>
                        )}
                        <div className="grid grid-cols-2 gap-4 text-gray-700">
                            <p><strong>ID:</strong> {selectedVehicle.vehicleId}</p>
                            <p><strong>Name:</strong> {selectedVehicle.vehicleName}</p>
                            <p><strong>Date:</strong> {selectedVehicle.date}</p>
                            <p><strong>Number:</strong> {selectedVehicle.vehicleNo}</p>
                            <p><strong>Chassis Number:</strong> {selectedVehicle.chassisNumber}</p>
                            <p><strong>Model:</strong> {selectedVehicle.model}</p>
                            <p><strong>Year:</strong> {selectedVehicle.year}</p>
                            <p><strong>Type:</strong> {selectedVehicle.vehicleType}</p>
                            <p><strong>Manufacturer:</strong> {selectedVehicle.manufacturer}</p>
                            <p><strong>Owner:</strong> {selectedVehicle.ownerName} ({selectedVehicle.ownerContact})</p>
                            <p><strong>Registration Date:</strong> {selectedVehicle.registrationDate}</p>
                            <p><strong>Insurance Expiry:</strong> {selectedVehicle.insuranceExpiry}</p>
                            <p className="col-span-2"><strong>Vehicle Document:</strong>
                                {selectedVehicle.vehicleDocument ? (
                                    <a href={selectedVehicle.vehicleDocument} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline ml-2">
                                        View Document
                                    </a>
                                ) : 'N/A'}
                            </p>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default VehicleTable;
