import { useState } from "react";
interface OperatorDetails {
    operatorName: string;
    street: string;
    postalCode: string;
    city: string;
    country: string;
    operatorId: string;
    taxId: string;
    vat: string;
    mainContact: string;
    contactEmail: string;
    invoiceContact: string;
    invoiceEmail: string;
    companyLogo: File | null;
}
interface FleetOperatorFormModalProps {
    isOpen: boolean;
    onClose: () => void;
    operatorDetails: OperatorDetails;
    setOperatorDetails: (details: OperatorDetails) => void;
}

const FleetOperatorForm: React.FC<FleetOperatorFormModalProps> = ({ isOpen, onClose }) => {
    if (!isOpen) return null;

    // State for form data
    const [formData, setFormData] = useState({
        operatorName: "",
        street: "",
        postalCode: "",
        city: "",
        country: "",
        operatorId: "",
        taxId: "",
        vat: "",
        mainContact: "",
        contactEmail: "",
        invoiceContact: "",
        invoiceEmail: "",
        companyLogo: null as File | null, // Allow both File and null
    });

    // State to toggle file input visibility
    const [showFileInput, setShowFileInput] = useState(true);

    // Handle input changes
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.name === "companyLogo" && e.target.files) {
            // Handle file upload
            const file = e.target.files[0];
            setFormData({ ...formData, companyLogo: file });
            setShowFileInput(false); // Hide the file input after upload
        } else {
            // Handle other inputs
            setFormData({ ...formData, [e.target.name]: e.target.value });
        }
    };

    // Handle file removal
    const handleRemoveFile = () => {
        setFormData({ ...formData, companyLogo: null }); // Clear the file
        setShowFileInput(true); // Show the file input again
    };

    return (
        <div className="fixed inset-0 flex items-center justify-center bg-black/75">
            <div className="bg-white p-6 rounded-lg shadow-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto hide-scrollbar">
                <h2 className="text-2xl font-bold">Add a new Fleet Operator</h2>
                <p className="text-gray-600 mb-4">
                    You can add/modify existing operators once the new operator has been created.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Operator Name */}
                    <div>
                        <label className="block text-gray-700 font-medium">Operator Name *</label>
                        <input
                            type="text"
                            name="operatorName"
                            value={formData.operatorName}
                            onChange={handleChange}
                            className="w-full p-2 border rounded-lg focus:ring focus:ring-blue-300"
                        />
                    </div>

                    {/* Street + House Number */}
                    <div>
                        <label className="block text-gray-700 font-medium">Street + House Number</label>
                        <input
                            type="text"
                            name="street"
                            value={formData.street}
                            onChange={handleChange}
                            className="w-full p-2 border rounded-lg focus:ring focus:ring-blue-300"
                        />
                    </div>

                    {/* Postal Code */}
                    <div>
                        <label className="block text-gray-700 font-medium">Postal Code *</label>
                        <input
                            type="text"
                            name="postalCode"
                            value={formData.postalCode}
                            onChange={handleChange}
                            className="w-full p-2 border rounded-lg focus:ring focus:ring-blue-300"
                        />
                    </div>

                    {/* City */}
                    <div>
                        <label className="block text-gray-700 font-medium">City *</label>
                        <input
                            type="text"
                            name="city"
                            value={formData.city}
                            onChange={handleChange}
                            className="w-full p-2 border rounded-lg focus:ring focus:ring-blue-300"
                        />
                    </div>

                    {/* Country */}
                    <div>
                        <label className="block text-gray-700 font-medium">Country *</label>
                        <input
                            type="text"
                            name="country"
                            value={formData.country}
                            onChange={handleChange}
                            className="w-full p-2 border rounded-lg focus:ring focus:ring-blue-300"
                        />
                    </div>

                    {/* Operator ID */}
                    <div>
                        <label className="block text-gray-700 font-medium">Operator ID</label>
                        <input
                            type="text"
                            value={formData.operatorId}
                            disabled
                            className="w-full p-2 border rounded-lg bg-gray-100 text-gray-500"
                        />
                    </div>

                    {/* Tax ID */}
                    <div>
                        <label className="block text-gray-700 font-medium">Tax ID *</label>
                        <input
                            type="text"
                            name="taxId"
                            value={formData.taxId}
                            onChange={handleChange}
                            className="w-full p-2 border rounded-lg focus:ring focus:ring-blue-300"
                        />
                    </div>

                    {/* VAT */}
                    <div>
                        <label className="block text-gray-700 font-medium">VAT % *</label>
                        <input
                            type="text"
                            name="vat"
                            value={formData.vat}
                            onChange={handleChange}
                            className="w-full p-2 border rounded-lg focus:ring focus:ring-blue-300"
                        />
                    </div>

                    {/* Main Contact */}
                    <div>
                        <label className="block text-gray-700 font-medium">Main Contact *</label>
                        <input
                            type="text"
                            name="mainContact"
                            value={formData.mainContact}
                            onChange={handleChange}
                            className="w-full p-2 border rounded-lg focus:ring focus:ring-blue-300"
                        />
                    </div>

                    {/* Contact Email */}
                    <div>
                        <label className="block text-gray-700 font-medium">Contact Email *</label>
                        <input
                            type="email"
                            name="contactEmail"
                            value={formData.contactEmail}
                            onChange={handleChange}
                            className="w-full p-2 border rounded-lg focus:ring focus:ring-blue-300"
                        />
                    </div>

                    {/* Invoice Contact */}
                    <div>
                        <label className="block text-gray-700 font-medium">Invoice Contact</label>
                        <input
                            type="text"
                            name="invoiceContact"
                            value={formData.invoiceContact}
                            onChange={handleChange}
                            className="w-full p-2 border rounded-lg focus:ring focus:ring-blue-300"
                        />
                    </div>

                    {/* Invoice Email */}
                    <div>
                        <label className="block text-gray-700 font-medium">Invoice Email *</label>
                        <input
                            type="email"
                            name="invoiceEmail"
                            value={formData.invoiceEmail}
                            onChange={handleChange}
                            className="w-full p-2 border rounded-lg focus:ring focus:ring-blue-300"
                        />
                    </div>

                    {/* Company Logo */}
                    <div>
                        <label className="block text-gray-700 font-medium">Company Logo</label>
                        {showFileInput ? (
                            // Show file input if no file is uploaded
                            <input
                                type="file"
                                name="companyLogo"
                                onChange={handleChange}
                                className="border p-2 w-full rounded-lg"
                            />
                        ) : (
                            // Show file name and remove button if a file is uploaded
                            <div className="flex items-center justify-between bg-gray-100 p-2 rounded-lg">
                                <span className="text-gray-700">{formData.companyLogo?.name}</span>
                                <button
                                    type="button"
                                    onClick={handleRemoveFile}
                                    className="text-red-600 hover:text-red-800"
                                >
                                    ×
                                </button>
                            </div>
                        )}
                    </div>
                </div>

                {/* Form Actions */}
                <div className="flex justify-end gap-4 mt-4">
                    <button onClick={onClose} className="px-4 py-2 bg-gray-200 rounded-lg">Cancel</button>
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg">Submit</button>
                </div>
            </div>
        </div>
    );
};

export default FleetOperatorForm;