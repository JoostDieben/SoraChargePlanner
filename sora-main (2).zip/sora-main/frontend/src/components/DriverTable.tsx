import React, { useState } from "react";
import { FaEdit, FaTrash, FaTimes } from "react-icons/fa";
import { Plus } from "lucide-react";
import DriverFormModal from "./DriverFormModal";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Buffer } from "buffer";


interface Driver {
    driverId: string;
    name: string;
    dateOfBirth: string;
    phoneNumber: string;
    email: string;
    company: string;
  
    driversLicense: string;
   
    licenseExpiry: string;
    driverPhoto: File | { type: 'Buffer'; data: number[] } | null;
    address: string;
}

interface DriversTableProps {
    drivers: Driver[];
    onDriverAdded: (newDriver: Driver) => void;
    refreshDrivers: () => void;
}

const DriversTable: React.FC<DriversTableProps> = ({ drivers, onDriverAdded, refreshDrivers }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedDriver, setSelectedDriver] = useState<Driver | null>(null);
    const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    const [searchTerm, setSearchTerm] = useState("");

    const rowsPerPage = 10;
    const totalPages = Math.ceil(drivers.length / rowsPerPage);
    const startIndex = (currentPage - 1) * rowsPerPage;

    const filteredDrivers = drivers.filter((driver) =>
        Object.values(driver).some((value) =>
            String(value).toLowerCase().includes(searchTerm.toLowerCase())
        )
    );

    const handleDeleteDriver = async (driverId: string) => {
    // Remove any # character if present
    const cleanDriverId = driverId.replace('#', '');
    
    if (!cleanDriverId) {
        toast.error("Driver ID is missing");
        return;
    }
    
    if (!window.confirm("Are you sure you want to delete this driver?")) return;

    try {
        const response = await fetch(`/api/drivers/${cleanDriverId}`, {
            method: "DELETE",
            headers: {
                'Content-Type': 'application/json',
            },
        });

        if (response.ok) {
            toast.success("Driver deleted successfully!");
            refreshDrivers();
        } else {
            const errorText = await response.text();
            try {
                const errorData = JSON.parse(errorText);
                toast.error(errorData.error || "Failed to delete driver.");
            } catch {
                toast.error(errorText || "Failed to delete driver.");
            }
        }
    } catch (error) {
        console.error("Error deleting driver:", error);
        toast.error("An error occurred while deleting the driver.");
    }
};

    const currentDrivers = filteredDrivers.slice(startIndex, startIndex + rowsPerPage);

    const handleViewDetails = (driver: Driver) => {
        setSelectedDriver(driver);
        setIsDetailsModalOpen(true);
    };

    const closeDetailsModal = () => {
        setIsDetailsModalOpen(false);
        setSelectedDriver(null);
    };

    const handleSaveSuccess = (newDriver: Driver) => {
        if (selectedDriver) {
            refreshDrivers();
        } else {
            onDriverAdded(newDriver);
        }
        setIsModalOpen(false);
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-lg">
            <ToastContainer position="top-center" autoClose={3000} />
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-semibold">Drivers</h2>
                <div className="flex items-center justify-end space-x-2">
                    <input
                        type="text"
                        placeholder="Search"
                        className="border p-2 rounded-md w-1/2"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                    <button
                        onClick={() => {
                            setSelectedDriver(null);
                            setIsModalOpen(true);
                        }}
                        className="bg-black text-white px-4 py-2 rounded-md flex items-center space-x-2"
                    >
                        <Plus size={16} />
                        <span>Add Driver</span>
                    </button>
                </div>
            </div>

            <table className="w-full border border-gray-200 rounded-md overflow-hidden">
                <thead>
                    <tr className="bg-gray-300 text-gray-700">
                        <th className="p-3 text-left">Driver ID</th>
                        <th className="p-3 text-left">Name</th>
                        <th className="p-3 text-left">License Number</th>
                        <th className="p-3 text-left">Phone</th>
                        <th className="p-3 text-left">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {currentDrivers.length > 0 ? (
                        currentDrivers.map((driver) => (
                            <tr key={driver.driverId} className="even:bg-gray-100 odd:bg-gray-50 hover:bg-gray-200 transition-all">
                                <td
                                    className="p-3 text-blue-500 cursor-pointer hover:underline"
                                    onClick={() => handleViewDetails(driver)}
                                >
                                    {driver.driverId}
                                </td>
                                <td className="p-3">{driver.name}</td>
                                <td className="p-3">{driver.driversLicense}</td>
                                <td className="p-3">{driver.phoneNumber}</td>
                                <td className="p-3 flex space-x-4">
                                    <button
                                        className="text-blue-500 hover:text-blue-700"
                                        onClick={() => { setSelectedDriver(driver); setIsModalOpen(true); }}
                                    >
                                        <FaEdit />
                                    </button>
                                    <button
                                        className="text-red-500 hover:text-red-700"
                                        onClick={() => {
                                            console.log("Deleting driver with ID:", driver.driverId);
                                            handleDeleteDriver(driver.driverId); // Pass raw ID without #
                                        }}
                                    >
                                        <FaTrash />
                                    </button>
                                </td>
                            </tr>
                        ))
                    ) : (
                        <tr>
                            <td colSpan={5} className="text-center p-4 text-gray-500">
                                No drivers found.
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>

            <div className="flex justify-between items-center mt-4">
                <button
                    className={`px-4 py-2 bg-gray-200 rounded-md ${currentPage === 1 ? "bg-gray-100 text-gray-500 cursor-not-allowed" : "hover:bg-gray-300"}`}
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage(currentPage - 1)}
                >
                    Previous
                </button>
                <span className="text-gray-700">Page {currentPage} of {totalPages}</span>
                <button
                    className={`px-4 py-2 bg-gray-200 rounded-md ${currentPage === totalPages ? "bg-gray-100 text-gray-500 cursor-not-allowed" : "hover:bg-gray-300"}`}
                    disabled={currentPage === totalPages}
                    onClick={() => setCurrentPage(currentPage + 1)}
                >
                    Next
                </button>
            </div>

            {isDetailsModalOpen && selectedDriver && (
                <div className="fixed inset-0 bg-black/65 bg-opacity-50 flex justify-center items-center p-4">
                    <div className="bg-white p-6 rounded-lg shadow-lg max-w-[50%] w-full relative">
                        <button onClick={closeDetailsModal} className="absolute top-4 right-4 text-gray-500 hover:text-gray-700">
                            <FaTimes size={20} />
                        </button>
                        <h3 className="text-2xl font-semibold mb-4 text-center">Driver Details</h3>
	
                       {selectedDriver.driverPhoto && "data" in selectedDriver.driverPhoto && (
    <img
        src={`data:image/jpeg;base64,${Buffer.from(selectedDriver.driverPhoto.data).toString("base64")}`}
        alt="Driver"
        className="w-32 h-32 object-cover rounded-full mx-auto mb-4"
    />
)}

                        <div className="grid grid-cols-2 gap-4 text-gray-700">
                            <p><strong>ID:</strong> #{selectedDriver.driverId}</p>
                            <p><strong>Name:</strong> {selectedDriver.name}</p>
                            <p><strong>Date of Birth:</strong> {selectedDriver.dateOfBirth}</p>
                            <p><strong>Phone:</strong> {selectedDriver.phoneNumber}</p>
                            <p><strong>Email:</strong> {selectedDriver.email}</p>
                            <p><strong>Company:</strong> {selectedDriver.company}</p>
                           
                            <p><strong>License Number:</strong> {selectedDriver.driversLicense}</p>
                          
                            <p><strong>License Expiry:</strong> {selectedDriver.licenseExpiry}</p>
                            <p className="col-span-2"><strong>Address:</strong> {selectedDriver.address}</p>
                        </div>
                    </div>
                </div>
            )}

            <DriverFormModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSave={handleSaveSuccess}
                existingDriver={selectedDriver}
            />
        </div>
    );
};

export default DriversTable;
