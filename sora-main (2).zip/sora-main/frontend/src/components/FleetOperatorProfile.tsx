import { useState } from "react";
import FleetOperatorFormModal from "./FleetOperatorFormModal";

interface OperatorDetails {
    operatorName: string;
    street: string;
    postalCode: string;
    city: string;
    country: string;
    operatorId: string;
    taxId: string;
    vat: string;
    mainContact: string;
    contactEmail: string;
    invoiceContact: string;
    invoiceEmail: string;
    companyLogo: File | null;
}

const FleetOperatorDetails = () => {
    const [isEditing, setIsEditing] = useState(false);
    const [operatorDetails, setOperatorDetails] = useState<OperatorDetails>({
        operatorName: "Girteka",
        street: "Somethingstrasse 11",
        postalCode: "BF44718",
        city: "Berlin",
        country: "Germany",
        operatorId: "#AF145",
        taxId: "NL33812B01",
        vat: "19%",
        mainContact: "Tom Jerry",
        contactEmail: "Tomandjerry@girteka.com",
        invoiceContact: "Mr. Big",
        invoiceEmail: "Finance@Girteka.com",
        companyLogo: null,
    });

    return (
        <div className="mx-auto bg-white p-6 ">
            <h2 className="text-xl font-semibold mb-4">Operator Details</h2>
            <div className="grid grid-cols-2 gap-4">
                {Object.entries(operatorDetails).map(([key, value]) => (
                    <div key={key}>
                        <p className="text-sm text-gray-500 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</p>
                        <p className="text-base font-medium">{value}</p>
                    </div>
                ))}
            </div>
            <div className="flex justify-end">
            <button
                className="mt-4 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                onClick={() => setIsEditing(true)}
            >
                Edit
            </button>
            </div>

            {/* Fleet Operator Edit Modal */}
            {isEditing && (
                <FleetOperatorFormModal
                    isOpen={isEditing}
                    onClose={() => setIsEditing(false)}
                    initialData={operatorDetails}
                    onSave={(updatedDetails: OperatorDetails) => {
                        setOperatorDetails(updatedDetails);
                        setIsEditing(false);
                    }}
                />
            )}
        </div>
    );
};

export default FleetOperatorDetails;
