import React, { useEffect, useState } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import CalendarTimePicker from "./CalendarTimePicker";

const DemoMap: React.FC = () => {
    const [showCalendar, setShowCalendar] = useState(false);
    const [sourceQuery, setSourceQuery] = useState("");
    const [destinationQuery, setDestinationQuery] = useState("");
    const [sourceSuggestions, setSourceSuggestions] = useState<any[]>([]);
    const [destinationSuggestions, setDestinationSuggestions] = useState<any[]>([]);
    const [map, setMap] = useState<L.Map | null>(null);
    const [sourceCoords, setSourceCoords] = useState<L.LatLngTuple | null>(null);
    const [destinationCoords, setDestinationCoords] = useState<L.LatLngTuple | null>(null);
    const [routeLayer, setRouteLayer] = useState<L.Polyline | null>(null);
    const [fuelStations, setFuelStations] = useState<L.LatLngTuple[]>([]);

    useEffect(() => {
        const mapContainer = document.getElementById("map");
        if (!mapContainer) return;

        const leafletMap = L.map(mapContainer).setView([51.90, 6.0], 7);

        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
            attribution: "© OpenStreetMap contributors",
        }).addTo(leafletMap);

        setMap(leafletMap);

        return () => {
            leafletMap.remove();
        };
    }, []);

    // Fetch location suggestions as the user types
    const fetchSuggestions = async (query: string, setSuggestions: React.Dispatch<React.SetStateAction<any[]>>) => {
        if (query.length < 3) {
            setSuggestions([]);
            return;
        }

        try {
            const response = await fetch(
                `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=5`
            );
            const data = await response.json();
            setSuggestions(data);
        } catch (error) {
            console.error("Error fetching suggestions:", error);
        }
    };

    // Get coordinates for a location name
    const getCoordinates = async (query: string): Promise<L.LatLngTuple | null> => {
        try {
            const response = await fetch(
                `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1`
            );
            const data = await response.json();
            if (data.length > 0) {
                return [parseFloat(data[0].lat), parseFloat(data[0].lon)] as L.LatLngTuple;
            }
        } catch (error) {
            console.error("Error fetching coordinates:", error);
        }
        return null;
    };

    // Draw route between source and destination
    const drawRoute = async (source: L.LatLngTuple, destination: L.LatLngTuple) => {
        if (!map) return;

        const osrmUrl = `https://router.project-osrm.org/route/v1/driving/${source[1]},${source[0]};${destination[1]},${destination[0]}?overview=full&geometries=geojson`;

        try {
            const response = await fetch(osrmUrl);
            const data = await response.json();

            if (data.routes && data.routes.length > 0) {
                const routeCoords: number[][] = data.routes[0].geometry.coordinates;
                const latlngs: L.LatLngTuple[] = routeCoords.map(coord => [coord[1], coord[0]]);

                // Remove previous route layer if it exists
                if (routeLayer) {
                    map.removeLayer(routeLayer);
                }

                // Draw the new route
                const newRouteLayer = L.polyline(latlngs, { color: "blue" }).addTo(map);
                setRouteLayer(newRouteLayer);

                // Fit the map to the route bounds
                map.fitBounds(newRouteLayer.getBounds());

                // Highlight start and end locations
                highlightLocations(source, destination);

                // Fetch and highlight fuel stations along the route
                fetchFuelStations(latlngs);
            } else {
                alert("No route found");
            }
        } catch (error) {
            console.error("Error fetching route:", error);
        }
    };

    // Highlight start and end locations
    const highlightLocations = (source: L.LatLngTuple, destination: L.LatLngTuple) => {
        if (!map) return;

        // Custom icons for start and end locations
        const startIcon = L.icon({
            iconUrl: "https://cdn-icons-png.flaticon.com/512/447/447031.png", // Start icon
            iconSize: [40, 40],
            iconAnchor: [20, 40],
        });

        const endIcon = L.icon({
            iconUrl: "https://cdn-icons-png.flaticon.com/512/447/447031.png", // End icon
            iconSize: [40, 40],
            iconAnchor: [20, 40],
        });

        // Add markers for start and end locations
        L.marker(source, { icon: startIcon }).addTo(map).bindPopup("Start Location").openPopup();
        L.marker(destination, { icon: endIcon }).addTo(map).bindPopup("End Location").openPopup();
    };

    // Fetch fuel stations along the route
    const fetchFuelStations = async (routeCoords: L.LatLngTuple[]) => {
        if (!map) return;

        try {
            // Use Overpass API to fetch fuel stations near the route
            const overpassUrl = `https://overpass-api.de/api/interpreter?data=[out:json];node["amenity"="fuel"](around:250,${routeCoords
                .map(coord => `${coord[0]},${coord[1]}`)
                .join(",")});out;`;

            const response = await fetch(overpassUrl);
            const data = await response.json();

            if (data.elements && data.elements.length > 0) {
                const stations: L.LatLngTuple[] = data.elements.map((element: any) => [
                    element.lat,
                    element.lon,
                ]);

                // Highlight fuel stations
                highlightFuelStations(stations);
            }
        } catch (error) {
            console.error("Error fetching fuel stations:", error);
        }
    };

    // Highlight fuel stations on the map
    const highlightFuelStations = (stations: L.LatLngTuple[]) => {
        if (!map) return;

        // Custom icon for fuel stations
        const fuelIcon = L.icon({
            iconUrl: "https://cdn-icons-png.flaticon.com/512/2038/2038854.png", // Fuel icon
            iconSize: [30, 30],
            iconAnchor: [15, 30],
        });

        // Add markers for fuel stations
        stations.forEach((station) => {
            L.marker(station, { icon: fuelIcon }).addTo(map).bindPopup("Fuel Station");
        });
    };

    // Handle form submission
    const handleSubmit = async () => {
        if (!map) return;

        const source = await getCoordinates(sourceQuery);
        const destination = await getCoordinates(destinationQuery);

        if (source && destination) {
            // Save coordinates
            setSourceCoords(source);
            setDestinationCoords(destination);

            // Draw the route
            drawRoute(source, destination);
        } else {
            alert("Invalid source or destination");
        }
    };

    return (
        <div className="h-[90vh] w-full relative">
            {/* Search Form */}
            <div className="absolute top-4 left-4 z-1000 bg-white p-4 rounded shadow w-96">
                <div className="mb-4">
                    <input
                        type="text"
                        value={sourceQuery}
                        onChange={(e) => {
                            setSourceQuery(e.target.value);
                            fetchSuggestions(e.target.value, setSourceSuggestions);
                        }}
                        placeholder="Source location..."
                        className="p-2 border rounded w-full"
                    />
                    {sourceSuggestions.length > 0 && (
                        <ul className="mt-2 border rounded bg-white">
                            {sourceSuggestions.map((suggestion, index) => (
                                <li
                                    key={index}
                                    className="p-2 hover:bg-gray-100 cursor-pointer"
                                    onClick={() => {
                                        setSourceQuery(suggestion.display_name);
                                        setSourceSuggestions([]);
                                    }}
                                >
                                    {suggestion.display_name}
                                </li>
                            ))}
                        </ul>
                    )}
                </div>

                <div className="mb-4">
                    <input
                        type="text"
                        value={destinationQuery}
                        onChange={(e) => {
                            setDestinationQuery(e.target.value);
                            fetchSuggestions(e.target.value, setDestinationSuggestions);
                        }}
                        placeholder="Destination location..."
                        className="p-2 border rounded w-full"
                    />
                    {destinationSuggestions.length > 0 && (
                        <ul className="mt-2 border rounded bg-white">
                            {destinationSuggestions.map((suggestion, index) => (
                                <li
                                    key={index}
                                    className="p-2 hover:bg-gray-100 cursor-pointer"
                                    onClick={() => {
                                        setDestinationQuery(suggestion.display_name);
                                        setDestinationSuggestions([]);
                                    }}
                                >
                                    {suggestion.display_name}
                                </li>
                            ))}
                        </ul>
                    )}
                </div>

                <button
                    onClick={handleSubmit}
                    className="p-2 bg-blue-500 text-white rounded w-full"
                >
                    Draw Route
                </button>
            </div>

            {/* Map Container */}
            <div id="map" className="h-full w-full"></div>

            {/* Popup Calendar */}
            {showCalendar && (
                <div
                    className="fixed inset-0 flex items-center justify-center bg-black/75"
                    style={{ zIndex: 1000 }}
                    onClick={() => setShowCalendar(false)}
                >
                    <div
                        className="bg-white p-6 rounded-lg shadow-lg w-[600px]"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <CalendarTimePicker onClose={() => setShowCalendar(false)} />
                    </div>
                </div>
            )}
        </div>
    );
};

export default DemoMap;