import React, { useRef, useEffect, useState } from "react";
import { FaArrowUp, FaArrowDown } from "react-icons/fa";
import { MdOutlineElectricBolt } from "react-icons/md";
import "react-datepicker/dist/react-datepicker.css";
import Map from "./Map";
import CalendarTimePicker from "./CalendarTimePicker";

interface Stop {
    time: string;
    title: string;
    address: string;
    details: string;
    icon?: React.ReactNode;
    statusIcon?: React.ReactNode;
}

interface TimelineProps {
    selectedRoute: string;
    orderId: string;
}

const initialStops: Stop[] = [
    {
        time: "06:30am",
        title: "Bonial International Gmbh",
        address: "Husitenstraße 32-33, 13355 Berlin, Germany",
        details: "1 Skid • 2.350 kg • 3 Pallets • Distance 112km",
        statusIcon: <FaArrowUp className="text-green-500" />,
    },
    {
        time: "09:55am",
        title: "DHL Packstation 507",
        address: "Schwartzkopffstraße 7 c, 10115 Magdeburg, Germany",
        details: "2 Skid • 3.130 kg • 2 Pallets • Distance 65km",
        statusIcon: <FaArrowDown className="text-red-500" />,
    },
    {
        time: "10:43am",
        title: "C1125 - Sora Charge Point",
        address: "Wöhlerstraße 12-13, 10115 Halle, Germany",
        details: "500kW Charge: 39min, 87% Battery • Distance 384km",
        icon: <MdOutlineElectricBolt className="text-yellow-500 text-xl" />,
    },
];

const Timeline: React.FC<TimelineProps> = ({ selectedRoute, orderId }) => {
    const stopRefs = useRef<(HTMLDivElement | null)[]>([]);
    const [selectedTab, setSelectedTab] = useState<"all" | "rest" | "charge">("all");
    const [stops, setStops] = useState<Stop[]>(initialStops);
    const [showModal, setShowModal] = useState(false);

    useEffect(() => {
        if (selectedRoute) {
            const index = stops.findIndex((stop) => stop.title === selectedRoute);
            if (index !== -1 && stopRefs.current[index]) {
                stopRefs.current[index]?.scrollIntoView({ behavior: "smooth", block: "center" });
            }
        }
    }, [selectedRoute, stops]);

    const filteredStops = stops.filter((stop) => {
        if (selectedTab === "all") return true;
        if (selectedTab === "charge") return stop.icon !== undefined;
        if (selectedTab === "rest") return stop.icon === undefined;
        return true;
    });

    const handleAddChargeStop = () => {
        setShowModal(true);
    };

    return (
        <div className="flex flex-col md:flex-row gap-4 p-4 bg-white rounded-lg h-[85vh]">
            <div className="w-full md:w-1/2 p-4 flex flex-col h-full">
                <div className="flex justify-between items-center border-b pb-2 mb-4">
                    <div className="flex">
                        <button className={`px-3 py-2 ${selectedTab === "all" ? "text-blue-500 border-b-2 border-blue-500" : "text-gray-400"}`} 
                            onClick={() => setSelectedTab("all")}>
                            All Stops
                        </button>
                        <button className={`px-3 py-2 ${selectedTab === "rest" ? "text-blue-500 border-b-2 border-blue-500" : "text-gray-400"}`} 
                            onClick={() => setSelectedTab("rest")}>
                            Rest Stops
                        </button>
                        <button className={`px-3 py-2 ${selectedTab === "charge" ? "text-blue-500 border-b-2 border-blue-500" : "text-gray-400"}`} 
                            onClick={() => setSelectedTab("charge")}>
                            Charge Stops
                        </button>
                    </div>
                    <div className="text-sm text-gray-600">Order ID: {orderId}</div>
                </div>
                <div className="relative pl-4 overflow-y-auto max-h-[70vh] pr-2">
                    {filteredStops.map((stop, index) => (
                        <div key={index} ref={(el) => { stopRefs.current[index] = el; }} className="relative flex gap-4 mb-6">
                            <div className="flex flex-col items-center">
                                <div className="w-4 h-4 bg-transparent border-3 border-blue-500 rounded-full"></div>
                                <p className="text-gray-500 text-sm">{stop.time}</p>
                            </div>
                            <div className="flex-1 bg-gray-100 p-3 rounded-lg shadow-md">
                                <p className="text-gray-500 text-sm">{stop.time}</p>
                                <h3 className="font-semibold text-lg flex items-center gap-2">{stop.icon} {stop.title}</h3>
                                <p className="text-gray-600 text-sm">{stop.address}</p>
                                <p className="text-gray-500 text-xs">{stop.details}</p>
                            </div>
                            <div>{stop.statusIcon}</div>
                        </div>
                    ))}
                </div>
                {selectedTab === "charge" && (
                    <div className="mt-4 text-center">
                        <button 
                            onClick={handleAddChargeStop} 
                            className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition duration-200"
                        >
                            Add Charge Stop
                        </button>
                    </div>
                )}
            </div>
            
            <div className="w-full md:w-1/2 p-4 h-full">
                <div className="h-full w-full bg-gray-200 rounded-lg overflow-hidden">
                    <Map />
                </div>
            </div>

           

            {showModal && (
                <div className="fixed inset-0 flex items-center justify-center bg-black/75 z-50" onClick={() => setShowModal(false)}>
                    <div className="bg-white p-6 rounded-lg shadow-lg w-[600px]" onClick={(e) => e.stopPropagation()}>
                        <CalendarTimePicker onClose={() => setShowModal(false)} orderId={orderId} />
                    </div>
                </div>
            )}
        </div>
    );
};

export default Timeline;
