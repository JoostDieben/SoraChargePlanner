import React, { useEffect, useState } from "react";
import axios from "axios";


interface Vehicle {
    vehicleId: number;
    vehicleName: string;
    date: string;
    vehicleNo: string;
    vin: string;
    batteryCapacity: string;
    dryRange: string;
    cRate: string;
    model: string;
    year: number;
    vehicleType: string;
    vehiclePhoto: string;
    vehicleDocument: string;
}

interface VehicleFormModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (newVehicle: Vehicle) => void;
    existingVehicle?: Vehicle;
    isEditing: boolean;
}

const VehicleFormModal: React.FC<VehicleFormModalProps> = ({ isOpen, onClose, onSave, existingVehicle, isEditing }) => {
    const [vehiclePhotoName, setVehiclePhotoName] = useState("");
    const [vehicleDocumentName, setVehicleDocumentName] = useState("");
    const [formData, setFormData] = useState<Vehicle>({
        vehicleId: 0,
        vehicleName: "",
        date: "",
        vehicleNo: "",
        vin: "",
        batteryCapacity: "",
        dryRange: "",
        cRate: "",
        model: "",
        year: 0,
        vehicleType: "",
        vehiclePhoto: "",
        vehicleDocument: "",
    });

    const [errors, setErrors] = useState<Record<string, string>>({});
    const [touched, setTouched] = useState<Record<string, boolean>>({});

    useEffect(() => {
        if (existingVehicle) {
            setFormData(existingVehicle);
        } else {
            setFormData({
                vehicleId: 0,
                vehicleName: "",
                date: "",
                vehicleNo: "",
                vin: "",
                batteryCapacity: "",
                dryRange: "",
                cRate: "",
                model: "",
                year: 0,
                vehicleType: "",
                vehiclePhoto: "",
                vehicleDocument: "",
            });
        }
        // Reset errors and touched when opening/closing modal
        setErrors({});
        setTouched({});
    }, [existingVehicle, isOpen]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));

        // Validate on change if the field has been touched
        if (touched[name]) {
            validateField(name, value);
        }
    };

    const handleBlur = (e: React.FocusEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setTouched(prev => ({ ...prev, [name]: true }));
        validateField(name, value);
    };

    const validateField = (name: string, value: string | number) => {
        const requiredFields = ['vehicleName', 'vehicleNo', 'vin', 'vehicleType',  'model', 'year', 'dryRange', 'batteryCapacity'];

        if (requiredFields.includes(name)) {
            const error = !value ? 'This field is required' : '';
            setErrors(prev => ({ ...prev, [name]: error }));
        }
    };

    const validateForm = () => {
        const newErrors: Record<string, string> = {};
        const requiredFields = ['vehicleName', 'vehicleNo', 'vin', 'vehicleType',  'model', 'year', 'dryRange', 'batteryCapacity'];


        requiredFields.forEach(field => {
            if (!formData[field as keyof Vehicle]) {
                newErrors[field] = 'This field is required';
            }
        });

        setErrors(newErrors);
        setTouched(prev => {
            const newTouched = { ...prev };
            requiredFields.forEach(field => {
                newTouched[field] = true;
            });
            return newTouched;
        });

        return Object.keys(newErrors).length === 0;
    };


    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, files } = e.target;
        if (files && files[0]) {
            const fileName = files[0].name;
            const reader = new FileReader();

            reader.onloadend = () => {
                // Update your form data with the file content
                setFormData(prev => ({
                    ...prev,
                    [name]: reader.result as string
                }));
            };

            reader.readAsDataURL(files[0]);

            // Update the respective file name state
            if (name === "vehiclePhoto") {
                setVehiclePhotoName(fileName);
            } else if (name === "vehicleDocument") {
                setVehicleDocumentName(fileName);
            }
        }
    };

    const handleRemoveFile = (fieldName: string) => {
        // Clear the file from form data
        setFormData(prev => ({
            ...prev,
            [fieldName]: ""
        }));

        // Clear the file name display
        if (fieldName === "vehiclePhoto") {
            setVehiclePhotoName("");
        } else if (fieldName === "vehicleDocument") {
            setVehicleDocumentName("");
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!validateForm()) {
            return;
        }

        const fleetManagerId = localStorage.getItem("userId");

        if (!fleetManagerId) {
            console.error("Fleet Manager ID is missing. User might not be logged in.");
            return;
        }
 
        try {
            const vehicleData = { ...formData, fleetManagerId };
            let savedVehicle;

            if (existingVehicle) {
                await axios.put(`/api/vehicles/${formData.vehicleId}`, vehicleData);
                savedVehicle = { ...vehicleData, vehicleId: formData.vehicleId };
            } else {
                const response = await axios.post("/api/vehicles", vehicleData);
                savedVehicle = response.data;
            }

            onSave(savedVehicle);
            onClose();
        } catch (error) {
            console.error("Error saving vehicle data:", error);
        }
    };

    const getInputClass = (name: string) => {
        return `w-full border p-2 rounded ${touched[name] && errors[name] ? 'border-red-500' : 'border-gray-300'}`;
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 flex items-center justify-center bg-black/75">
            <div className="bg-white p-6 rounded-lg shadow-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto hide-scrollbar">
                <h2 className="text-xl font-semibold mb-4">{existingVehicle ? "Edit Vehicle" : "Add New Vehicle"}</h2>
                <p className="text-gray-600 mb-4">Vehicle Details</p>

                <form onSubmit={handleSubmit}>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium">Make*</label>
                            <input
                                type="text"
                                name="vehicleName"
                                placeholder="e.g., Volvo"
                                value={formData.vehicleName}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                className={getInputClass('vehicleName')}
                            />
                            {touched.vehicleName && errors.vehicleName && (
                                <p className="text-red-500 text-xs mt-1">{errors.vehicleName}</p>
                            )}
                        </div>
                        <div>
                            <label className="block text-sm font-medium">License Plate*</label>
                            <input
                                type="text"
                                name="vehicleNo"
                                value={formData.vehicleNo}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                className={getInputClass('vehicleNo')}
                            />
                            {touched.vehicleNo && errors.vehicleNo && (
                                <p className="text-red-500 text-xs mt-1">{errors.vehicleNo}</p>
                            )}
                        </div>
                        <div>
                            <label className="block text-sm font-medium">VIN Number*</label>
                            <input
                                type="text"
                                name="vin"
                                value={formData.vin}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                className={getInputClass('vin')}
                            />
                            {touched.vin && errors.vin && (
                                <p className="text-red-500 text-xs mt-1">{errors.vin}</p>
                            )}
                        </div>
                        <div>
                            <label className="block text-sm font-medium">Model*</label>
                            <input
                                type="text"
                                name="vehicleType"
                                value={formData.vehicleType}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                className={getInputClass('vehicleType')}
                            />
                            {touched.vehicleType && errors.vehicleType && (
                                <p className="text-red-500 text-xs mt-1">{errors.vehicleType}</p>
                            )}
                        </div>
                        <div>
                            <label className="block text-sm font-medium">Model Type*</label>
                            <input
                                type="text"
                                name="model"
                                value={formData.model}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                className={getInputClass('model')}
                            />
                            {touched.model && errors.model && (
                                <p className="text-red-500 text-xs mt-1">{errors.model}</p>
                            )}
                        </div>
                        <div>
                            <label className="block text-sm font-medium">Registration Year*</label>
                            <input
                                type="number"
                                name="year"
                                value={formData.year || ''}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                className={getInputClass('year')}
                            />
                            {touched.year && errors.year && (
                                <p className="text-red-500 text-xs mt-1">{errors.year}</p>
                            )}
                        </div>
                        <div>
                            <label className="block text-sm font-medium">Battery Capacity*</label>
                            <input
                                type="text"
                                name="batteryCapacity"
                                value={formData.batteryCapacity}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                className={getInputClass('batteryCapacity')}
                            />
                            {touched.batteryCapacity && errors.batteryCapacity && (
                                <p className="text-red-500 text-xs mt-1">{errors.batteryCapacity}</p>
                            )}
                        </div>
                        <div>
                            <label className="block text-sm font-medium">Dry Range*</label>
                            <input
                                type="text"
                                name="dryRange"
                                value={formData.dryRange}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                className={getInputClass('dryRange')}
                            />
                            {touched.dryRange && errors.dryRange && (
                                <p className="text-red-500 text-xs mt-1">{errors.dryRange}</p>
                            )}
                        </div>
                        <div>
                            <label className="block text-sm font-medium">Max Charge C-Rate*</label>
                            <input
                                type="text"
                                name="cRate"
                                value={formData.cRate}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                className={getInputClass('cRate')}
                            />
                        </div>
                        
                        <div>
                            <label className="block text-sm font-medium">Vehicle Photo</label>
                            {!vehiclePhotoName ? (
                                <input
                                    type="file"
                                    name="vehiclePhoto"
                                    onChange={handleFileChange}
                                    className="w-full border p-2 rounded border-gray-300"
                                />
                            ) : (
                                <div className="flex items-center justify-between p-2 border rounded bg-gray-50 mt-2">
                                    <span className="text-sm text-gray-700 truncate">{vehiclePhotoName}</span>
                                    <button
                                        type="button"
                                        onClick={() => handleRemoveFile("vehiclePhoto")}
                                        className="ml-2 text-red-500 hover:text-red-700"
                                    >
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                            <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                                        </svg>
                                    </button>
                                </div>
                            )}
                        </div>

                        <div>
                            <label className="block text-sm font-medium">Vehicle Document</label>
                            {!vehicleDocumentName ? (
                                <input
                                    type="file"
                                    name="vehicleDocument"
                                    onChange={handleFileChange}
                                    className="w-full border p-2 rounded border-gray-300"
                                />
                            ) : (
                                <div className="flex items-center justify-between p-2 border rounded bg-gray-50 mt-2">
                                    <span className="text-sm text-gray-700 truncate">{vehicleDocumentName}</span>
                                    <button
                                        type="button"
                                        onClick={() => handleRemoveFile("vehicleDocument")}
                                        className="ml-2 text-red-500 hover:text-red-700"
                                    >
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                            <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                                        </svg>
                                    </button>
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="flex justify-end space-x-2 mt-6">
                        <button
                            type="button"
                            className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400 transition-colors"
                            onClick={onClose}
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
                        >
                            {existingVehicle ? "Update Vehicle" : "Add Vehicle"}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default VehicleFormModal;
