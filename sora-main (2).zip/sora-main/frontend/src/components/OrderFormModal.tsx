import { useState, useRef, useEffect } from "react";
import axios from 'axios';


interface Order {
    OrderId: string;
    name: string;
    quantity: number;
    route: string;
    startLocation: string;
    endLocation: string;
    customer: string;
    items: string;
    weight: string;
    startDateTime: string;
    endDateTime: string;
    tripType: string;
    type: string;
    operatingDays: string;
    driverId: string;
    vehicleId: string;
}

interface OrderFormModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (order: Order) => void;
    order?: Order | null;
    isEditing?: boolean;
}

const OrderFormModal: React.FC<OrderFormModalProps> = ({ isOpen, onClose, onSave, order, isEditing = false }) => {
    const [formData, setFormData] = useState<Order>({
        OrderId: order?.OrderId || "",
        name: order?.name || "",
        quantity: order?.quantity || 1,
        route: order?.route || "",
        startLocation: order?.startLocation || "",
        endLocation: order?.endLocation || "",
        customer: order?.customer || "",
        items: order?.items || "",
        weight: order?.weight || "",
        startDateTime: order?.startDateTime || "",
        endDateTime: order?.endDateTime || "",
        tripType: order?.tripType || "Shuttle",
        type: order?.type || "",
        operatingDays: order?.operatingDays || "",
        driverId: order?.driverId || "",
        vehicleId: order?.vehicleId || "",
    });

    const [errors, setErrors] = useState<Record<string, string>>({});
    const [touched, setTouched] = useState<Record<string, boolean>>({});
    const [drivers, setDrivers] = useState<DriverAttributes[]>([]);
    const [vehicles, setVehicles] = useState<VehicleAttributes[]>([]);
    const daysOfWeek = ['Mon', 'Tue', 'Wed', 'Thurs', 'Fri', 'Sat', 'Sun'];
    const [showDropdown, setShowDropdown] = useState(false);
    const [selectedDays, setSelectedDays] = useState(
        formData.operatingDays ? formData.operatingDays.split(', ') : []
    );

    // Define the ref with a proper type
    const dropdownRef = useRef<HTMLDivElement | null>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (
                dropdownRef.current &&
                !dropdownRef.current.contains(event.target as Node)
            ) {
                setShowDropdown(false);
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    useEffect(() => {
        if (isOpen) {
            const fleetManagerId = localStorage.getItem("userId");
            if (fleetManagerId) {
                // Fetch drivers
                axios.get(`/api/drivers/fleetManager/${fleetManagerId}`)
                    .then(response => setDrivers(response.data))
                    .catch(error => console.error("Error fetching drivers:", error));

                // Fetch vehicles
                axios.get(`/api/vehicles/fleetManager/${fleetManagerId}`)
                    .then(response => setVehicles(response.data))
                    .catch(error => console.error("Error fetching vehicles:", error));
            }
        }
    }, [isOpen]);

    useEffect(() => {
        if (order) {
            setFormData({
                OrderId: order.OrderId,
                name: order.name,
                quantity: order.quantity,
                route: order.route,
                startLocation: order.startLocation,
                endLocation: order.endLocation,
                customer: order.customer,
                items: order.items,
                weight: order.weight,
                startDateTime: order.startDateTime,
                endDateTime: order.endDateTime,
                tripType: order.tripType,
                type: order.type,
                operatingDays: order.operatingDays,
                driverId: order.driverId,
                vehicleId: order.vehicleId,
            });
        } else {
            setFormData({
                OrderId: "",
                name: "",
                quantity: 1,
                route: "",
                startLocation: "",
                endLocation: "",
                customer: "",
                items: "",
                weight: "",
                startDateTime: "",
                endDateTime: "",
                tripType: "Shuttle",
                type: "",
                operatingDays: "",
                driverId: "",
                vehicleId: "",
            });
        }
        setErrors({});
        setTouched({});
    }, [order]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: name === "quantity" ? Number(value) : value }));

        if (touched[name]) {
            validateField(name, value);
        }
    };

    const handleBlur = (e: React.FocusEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setTouched(prev => ({ ...prev, [name]: true }));
        validateField(name, value);
    };

    const validateField = (name: string, value: string | number) => {
        let error = '';

        if (!value) {
            error = 'This field is required';
        } else if (name === 'quantity' && Number(value) <= 0) {
            error = 'Quantity must be greater than 0';
        } else if ((name === 'startDateTime' || name === 'endDateTime') && value) {
            const date = new Date(value as string);
            if (isNaN(date.getTime())) {
                error = 'Invalid date/time';
            }
        }

        setErrors(prev => ({ ...prev, [name]: error }));
    };

    const validateForm = () => {
        const newErrors: Record<string, string> = {};
        const fieldsToValidate = [
            'name', 'quantity', 'startLocation', 'endLocation',
            'startDateTime', 'endDateTime', 'type', 'tripType',
            'driverId', 'vehicleId'
        ];

        fieldsToValidate.forEach(field => {
            const value = formData[field as keyof Order];
            if (!value) {
                newErrors[field] = 'This field is required';
            } else if (field === 'quantity' && Number(value) <= 0) {
                newErrors[field] = 'Quantity must be greater than 0';
            }
        });

        // Validate date range
        if (formData.startDateTime && formData.endDateTime) {
            const startDate = new Date(formData.startDateTime);
            const endDate = new Date(formData.endDateTime);
            if (startDate >= endDate) {
                newErrors.endDateTime = 'End date/time must be after start date/time';
            }
        }

        setErrors(newErrors);
        setTouched(prev => {
            const newTouched = { ...prev };
            fieldsToValidate.forEach(field => {
                newTouched[field] = true;
            });
            return newTouched;
        });

        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!validateForm()) {
            return;
        }

        const fleetManagerId = localStorage.getItem("userId");
        if (!fleetManagerId) {
            alert("Fleet Manager ID is missing. User might not be logged in.");
            return;
        }

        try {
            const url = isEditing && formData.OrderId
                ? `/api/orders/${formData.OrderId}`
                : "/api/orders";

            const method = isEditing && formData.OrderId ? "PUT" : "POST";

            const response = await axios({
                method,
                url,
                headers: { "Content-Type": "application/json" },
                data: {
                    ...formData,
                    fleetManagerId: parseInt(fleetManagerId),
                },
            });

            if (response.status >= 200 && response.status < 300) {
                onSave(response.data);
                onClose();
            } else {
                alert(`Failed to ${isEditing ? 'update' : 'add'} order: ${response.status} ${response.statusText}`);
            }
        } catch (error: any) {
            console.error("Error while saving order:", error);
            alert(error.response?.data?.message || "An error occurred while saving the order.");
        }
    };

    const getInputClass = (name: string) => {
        return `w-full border p-2 rounded ${touched[name] && errors[name] ? 'border-red-500' : 'border-gray-300'
            }`;
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 flex items-center justify-center bg-black/75">
            <div className="bg-white p-6 rounded-lg shadow-lg max-w-2xl max-h-[85vh] w-full overflow-y-auto">
                <h2 className="text-xl font-semibold mb-4">{isEditing ? "Edit Order" : "Add New Order"}</h2>
                <p className="text-gray-600 mb-4">Order Details</p>

                <form onSubmit={handleSubmit}>
                    <div className="grid grid-cols-2 gap-4">
                        {/* Start Location */}
                        <div>
                            <label className="block text-sm font-medium">Start Location *</label>
                            <input
                                type="text"
                                name="startLocation"
                                className={getInputClass('startLocation')}
                                value={formData.startLocation}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                required
                            />
                            {touched.startLocation && errors.startLocation && (
                                <p className="text-red-500 text-xs mt-1">{errors.startLocation}</p>
                            )}
                        </div>

                        {/* End Location */}
                        <div>
                            <label className="block text-sm font-medium">End Location *</label>
                            <input
                                type="text"
                                name="endLocation"
                                className={getInputClass('endLocation')}
                                value={formData.endLocation}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                required
                            />
                            {touched.endLocation && errors.endLocation && (
                                <p className="text-red-500 text-xs mt-1">{errors.endLocation}</p>
                            )}
                        </div>

                        {/* Order Name */}
                        <div>
                            <label className="block text-sm font-medium">Order Name *</label>
                            <input
                                type="text"
                                name="name"
                                className={getInputClass('name')}
                                value={formData.name}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                required
                            />
                            {touched.name && errors.name && (
                                <p className="text-red-500 text-xs mt-1">{errors.name}</p>
                            )}
                        </div>

                        {/* Start Date & Time */}
                        <div>
                            <label className="block text-sm font-medium">Start Date & Time *</label>
                            <input
                                type="datetime-local"
                                name="startDateTime"
                                className={getInputClass('startDateTime')}
                                value={formData.startDateTime}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                required
                            />
                            {touched.startDateTime && errors.startDateTime && (
                                <p className="text-red-500 text-xs mt-1">{errors.startDateTime}</p>
                            )}
                        </div>

                        {/* End Date & Time */}
                        <div>
                            <label className="block text-sm font-medium">End Date & Time *</label>
                            <input
                                type="datetime-local"
                                name="endDateTime"
                                className={getInputClass('endDateTime')}
                                value={formData.endDateTime}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                required
                            />
                            {touched.endDateTime && errors.endDateTime && (
                                <p className="text-red-500 text-xs mt-1">{errors.endDateTime}</p>
                            )}
                        </div>

                        {/* Type */}
                        <div>
                            <label className="block text-sm font-medium">Type *</label>
                            <select
                                name="type"
                                className={getInputClass('type')}
                                value={formData.type}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                required
                            >
                                <option value="">Select Type</option>
                                <option value="Pick-up">Pick-up</option>
                                <option value="Drop-off">Drop-off</option>
                            </select>
                            {touched.type && errors.type && (
                                <p className="text-red-500 text-xs mt-1">{errors.type}</p>
                            )}
                        </div>

                        {/* Customer */}
                        <div>
                            <label className="block text-sm font-medium">Customer *</label>
                            <input
                                type="text"
                                name="customer"
                                className={getInputClass('customer')}
                                value={formData.customer}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                required
                            />
                            {touched.customer && errors.customer && (
                                <p className="text-red-500 text-xs mt-1">{errors.customer}</p>
                            )}
                        </div>

                        {/* Route */}
                        <div>
                            <label className="block text-sm font-medium">Route *</label>
                            <input
                                type="text"
                                name="route"
                                className={getInputClass('route')}
                                value={formData.route}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                required
                            />
                            {touched.route && errors.route && (
                                <p className="text-red-500 text-xs mt-1">{errors.route}</p>
                            )}
                        </div>

                        {/* Order Type */}
                        <div>
                            <label className="block text-sm font-medium">Order Type *</label>
                            <select
                                name="tripType"
                                className={getInputClass('tripType')}
                                value={formData.tripType}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                required
                            >
                                <option value="Shuttle">Shuttle</option>
                                <option value="Delivery">Delivery</option>
                            </select>
                            {touched.tripType && errors.tripType && (
                                <p className="text-red-500 text-xs mt-1">{errors.tripType}</p>
                            )}
                        </div>

                       {/* Operating Days */}
                        <div className="relative" ref={dropdownRef}>
                            <label className="block text-sm font-medium mb-1">Operating Days *</label>

                            <div
                                onClick={() => setShowDropdown(!showDropdown)}
                                className="cursor-pointer border rounded px-3 py-2 bg-white"
                            >
                                {selectedDays.length ? selectedDays.join(', ') : 'Select Operating Days'}
                            </div>

                            {showDropdown && (
                                <div className="absolute z-10 mt-1 w-full bg-white border rounded shadow-md max-h-60 overflow-y-auto">
                                    <div className="p-2 border-b">
                                        <label className="inline-flex items-center space-x-2">
                                            <input
                                                type="checkbox"
                                                checked={selectedDays.length === daysOfWeek.length}
                                                onChange={() => {
                                                    const updated = selectedDays.length === daysOfWeek.length ? [] : [...daysOfWeek];
                                                    setSelectedDays(updated);
                                                    setFormData(prev => ({ ...prev, operatingDays: updated.join(', ') }));
                                                }}
                                            />
                                            <span>Select All</span>
                                        </label>
                                    </div>
                                    {daysOfWeek.map(day => (
                                        <div key={day} className="p-2">
                                            <label className="inline-flex items-center space-x-2">
                                                <input
                                                    type="checkbox"
                                                    checked={selectedDays.includes(day)}
                                                    onChange={() => {
                                                        const updated = selectedDays.includes(day)
                                                            ? selectedDays.filter(d => d !== day)
                                                            : [...selectedDays, day];
                                                        setSelectedDays(updated);
                                                        setFormData(prev => ({ ...prev, operatingDays: updated.join(', ') }));
                                                    }}
                                                />
                                                <span>{day}</span>
                                            </label>
                                        </div>
                                    ))}
                                </div>
                            )}

                            {touched.operatingDays && errors.operatingDays && (
                                <p className="text-red-500 text-xs mt-1">{errors.operatingDays}</p>
                            )}
                        </div>

                        {/* Items */}
                        <div>
                            <label className="block text-sm font-medium">Items *</label>
                            <input
                                type="text"
                                name="items"
                                className={getInputClass('items')}
                                placeholder="Item 1, Item 2"
                                value={formData.items}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                required
                            />
                            {touched.items && errors.items && (
                                <p className="text-red-500 text-xs mt-1">{errors.items}</p>
                            )}
                        </div>

                        {/* Number of Items */}
                        <div>
                            <label className="block text-sm font-medium">Number of Items *</label>
                            <input
                                type="number"
                                name="quantity"
                                className={getInputClass('quantity')}
                                value={formData.quantity}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                min="1"
                                required
                            />
                            {touched.quantity && errors.quantity && (
                                <p className="text-red-500 text-xs mt-1">{errors.quantity}</p>
                            )}
                        </div>

                        {/* Weight */}
                        <div>
                            <label className="block text-sm font-medium">Weight in KG *</label>
                            <input
                                type="text"
                                name="weight"
                                className={getInputClass('weight')}
                                value={formData.weight}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                required
                            />
                            {touched.weight && errors.weight && (
                                <p className="text-red-500 text-xs mt-1">{errors.weight}</p>
                            )}
                        </div>

                        {/* Driver */}
                        <div>
                            <label className="block text-sm font-medium">Driver *</label>
                            <select
                                name="driverId"
                                className={getInputClass('driverId')}
                                value={formData.driverId}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                required
                            >
                                <option value="">Select a driver</option>
                                {drivers.map(driver => (
                                    <option key={driver.driverId} value={driver.driverId}>
                                        {driver.name}
                                    </option>
                                ))}
                            </select>
                            {touched.driverId && errors.driverId && (
                                <p className="text-red-500 text-xs mt-1">{errors.driverId}</p>
                            )}
                        </div>

                        {/* Vehicle */}
                        <div>
                            <label className="block text-sm font-medium">Vehicle *</label>
                            <select
                                name="vehicleId"
                                className={getInputClass('vehicleId')}
                                value={formData.vehicleId}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                required
                            >
                                <option value="">Select a vehicle</option>
                                {vehicles.map(vehicle => (
                                    <option key={vehicle.vehicleId} value={vehicle.vehicleId}>
                                        {vehicle.vehicleName} ({vehicle.vehicleNo})
                                    </option>
                                ))}
                            </select>
                            {touched.vehicleId && errors.vehicleId && (
                                <p className="text-red-500 text-xs mt-1">{errors.vehicleId}</p>
                            )}
                        </div>
                    </div>

                    <div className="flex justify-end space-x-2 mt-6">
                        <button
                            type="button"
                            className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400 transition-colors"
                            onClick={onClose}
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
                        >
                            {isEditing ? "Update Order" : "Add Order"}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default OrderFormModal;
