import React, { useState, useEffect } from "react";
import OrdersTable from "../components/OrderTable";
import DriverTable from "../components/DriverTable";
import VehicleTable from "../components/VehicleTable";
import { fetchUser } from "../services/userService";
import FleetOperatorForm from "./FleetOperatorFormModal";
import FleetOperatorDetails from "./FleetOperatorProfile";

const FleetPartner: React.FC = () => {
    const [activeWindow, setActiveWindow] = useState<string>(
        localStorage.getItem("activeWindow") ?? "Orders"
    );
    const [selectedFleetOperator, setSelectedFleetOperator] = useState<string>("");
    const [isFleetOperatorModalOpen, setIsFleetOperatorModalOpen] = useState<boolean>(false); // State for modal
    const [user, setUser] = useState<any>(null);
    const [drivers, setDrivers] = useState<any[]>([]);
    const [vehicles, setVehicles] = useState<any[]>([]);
    const [orders, setOrders] = useState<any[]>([]);
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        localStorage.setItem("activeWindow", activeWindow);
    }, [activeWindow]);

    const fleetOperators = ["Operator 1", "Operator 2", "Operator 3"];
    const sections = ["fleetPartnerprofile", "orders", "vehicles", "drivers"];

    const getUser = async () => {
        const userId = localStorage.getItem("userId");
        if (!userId) return;

        try {
            const userData = await fetchUser(userId);
            setUser(userData);
        } catch (error) {
            console.error("Failed to fetch user:", error);
        }
    };

    const fetchDrivers = async () => {
        try {
            const response = await fetch("http://localhost:5000/api/drivers/all");
            const data = await response.json();
            if (response.ok) {
                setDrivers(data);
            } else {
                console.error("Failed to fetch drivers:", data.message);
            }
        } catch (error) {
            console.error("Error fetching drivers:", error);
        }
    };

    const fetchVehicles = async () => {
        try {
            const response = await fetch("http://localhost:5000/api/vehicles");
            const data = await response.json();
            if (response.ok) {
                setVehicles(Array.isArray(data) ? data : []);
            } else {
                console.error("Failed to fetch Vehicles:", data.message);
                setVehicles([]);
            }
        } catch (error) {
            console.error("Error fetching Vehicles:", error);
            setVehicles([]);
        }
    };

    const fetchOrders = async () => {
        try {
            const response = await fetch("http://localhost:5000/api/orders");
            const data = await response.json();
            if (response.ok) {
                setOrders(Array.isArray(data) ? data : []);
            } else {
                console.error("Failed to fetch Orders:", data.message);
                setOrders([]);
            }
        } catch (error) {
            console.error("Error fetching Orders:", error);
            setOrders([]);
        }
    };

    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            try {
                await Promise.all([getUser(), fetchDrivers(), fetchVehicles(), fetchOrders()]);
            } catch (error) {
                setError("Failed to fetch data");
                console.error(error);
            } finally {
                setIsLoading(false);
            }
        };

        fetchData();
    }, []);

    const handleSaveOrder = (newOrder: any) => {
        setOrders((prevOrders) => [...prevOrders, newOrder]);
    };

    if (isLoading) {
        return <div className="text-center mt-10">Loading...</div>;
    }

    if (error) {
        return <div className="text-center mt-10 text-red-500">Error: {error}</div>;
    }

    return (
        <div className="p-6 bg-gray-100 h-screen overflow-y-auto hide-scrollbar">
            {/* Dropdowns & Button */}
            <div className="flex justify-between items-center mb-6 bg-white p-4 ">
                <div className="flex gap-4">
                    {/* Fleet Operator Dropdown */}
                    <select
                        className="p-2 border border-gray-300 rounded-lg"
                        value={selectedFleetOperator}
                        onChange={(e) => setSelectedFleetOperator(e.target.value)}
                    >
                        <option value="">Select Fleet Operator</option>
                        {fleetOperators.map((operator) => (
                            <option key={operator} value={operator}>
                                {operator}
                            </option>
                        ))}
                    </select>

                    {/* Section Dropdown */}
                    <select
                        className="p-2 border border-gray-300 rounded-lg"
                        value={activeWindow}
                        onChange={(e) => setActiveWindow(e.target.value)}
                    >
                        {sections.map((section) => (
                            <option key={section} value={section}>
                                {section.charAt(0).toUpperCase() + section.slice(1)}
                            </option>
                        ))}
                    </select>
                </div>

                {/* Add Fleet Partner Button */}
                <button
                    className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600"
                    onClick={() => setIsFleetOperatorModalOpen(true)} // Open modal on click
                >
                    Add Fleet Partner
                </button>
            </div>
            {/* Fleet Operator Form Modal */}
            <FleetOperatorForm
                isOpen={isFleetOperatorModalOpen}
                onClose={() => setIsFleetOperatorModalOpen(false)}
                
            />

            {/* Dynamic Section Display */}
            <div className="bg-white ">
                {activeWindow === "orders" && <OrdersTable orders={orders} onSave={handleSaveOrder} />}
                {activeWindow === "drivers" && <DriverTable drivers={drivers} />}
                {activeWindow === "vehicles" && <VehicleTable vehicles={vehicles} />}
                {activeWindow === "fleetPartnerprofile" && <FleetOperatorDetails/>}
            </div>
        </div>
    );
};

export default FleetPartner;