import { useState } from "react";
import { FaChevronLeft, FaChevronRight, FaSignOutAlt } from "react-icons/fa";
import { useNavigate } from "react-router-dom";

interface MenuItem {
    name: string;
    icon: JSX.Element;
}

interface SidebarProps {
    activeSection: string;
    setActiveSection: (section: string) => void;
    menuItems: MenuItem[];
}

const Sidebar = ({ activeSection, setActiveSection, menuItems }: SidebarProps) => {
    const [isCollapsed, setIsCollapsed] = useState(false);
    const navigate = useNavigate();

    const handleLogout = () => {
        // Clear all user-related data from storage
        localStorage.removeItem("token");
        localStorage.removeItem("userId");
        localStorage.removeItem("activeSection");

        // Clear session storage if used
        sessionStorage.clear();

        // Clear cookies if used
        document.cookie.split(";").forEach((c) => {
            document.cookie = c
                .replace(/^ +/, "")
                .replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/");
        });

        // Navigate to login page
        navigate("/");
    };

    return (
        <div className={`h-screen bg-gray-900 text-white flex flex-col transition-all duration-300 ${isCollapsed ? "w-20" : "w-64"} p-4`}>
            {/* Logo */}
            <div className="flex justify-center mb-6">
                <img
                    src="/images/whiteLogo.png"
                    alt="Logo"
                    className={`transition-all ${isCollapsed ? "w-12" : "w-24"}`}
                />
            </div>

            {/* Menu Items */}
            <ul className="flex-1 space-y-2">
                {menuItems.map((item) => (
                    <li
                        key={item.name}
                        className={`flex items-center px-4 py-3 cursor-pointer rounded-lg transition-all duration-200
                            ${activeSection === item.name ? "bg-blue-600" : "hover:bg-gray-700"}`}
                        onClick={() => {
                            setActiveSection(item.name);
                            // Store the active section in localStorage
                            localStorage.setItem("activeSection", item.name);
                        }}
                    >
                        <span className="text-xl">{item.icon}</span>
                        {!isCollapsed && (
                            <span className="ml-3 text-sm font-medium">{item.name}</span>
                        )}
                    </li>
                ))}
            </ul>

            {/* Logout Button */}
            <div className="mt-auto mb-4">
                <button
                    onClick={handleLogout}
                    className={`flex items-center w-full text-left text-red-400 hover:text-red-300 py-3 px-4 rounded-lg hover:bg-gray-800 transition
                        ${isCollapsed ? "justify-center" : ""}`}
                >
                    <FaSignOutAlt size={18} />
                    {!isCollapsed && (
                        <span className="ml-3 text-sm font-medium">Logout</span>
                    )}
                </button>
            </div>

            {/* Collapse Toggle Button */}
            <div className="flex justify-end">
                <button
                    onClick={() => setIsCollapsed(!isCollapsed)}
                    className="text-gray-300 hover:text-white p-2 rounded-full hover:bg-gray-700 transition"
                    aria-label={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
                >
                    {isCollapsed ? (
                        <FaChevronRight size={16} />
                    ) : (
                        <FaChevronLeft size={16} />
                    )}
                </button>
            </div>
        </div>
    );
};

export default Sidebar;