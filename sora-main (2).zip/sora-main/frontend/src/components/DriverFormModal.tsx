import { useState, useEffect } from "react";
import { addDriver, updateDriver } from "../services/driverService";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

interface Driver {
    driverId: string;
    name: string;
    dateOfBirth: string;
    phoneNumber: string;
    countryCode: string;
    email: string;
    company: string;
  
    driversLicense: string;
    
    licenseExpiry: string;
    driverPhoto: File | null;
    address: string;
}

interface DriverFormModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (savedDriver: Driver) => void;
    existingDriver?: Driver | null;
}

const DriverFormModal: React.FC<DriverFormModalProps> = ({ isOpen, onClose, onSave, existingDriver }) => {
    const [formData, setFormData] = useState<Driver>({
        driverId: "",
        name: "",
        dateOfBirth: "",
        phoneNumber: "",
        countryCode: "+1", // Default country code
        email: "",
        company: "",
        
        driversLicense: "",
       
        licenseExpiry: "",
        driverPhoto: null,
        address: "",
    });

    const [errors, setErrors] = useState<Record<string, string>>({});
    const [touched, setTouched] = useState<Record<string, boolean>>({});
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [selectedFileName, setSelectedFileName] = useState("");

    useEffect(() => {
        if (existingDriver) {
            // Split existing phone number into country code and number if it contains a +
            if (existingDriver.phoneNumber && existingDriver.phoneNumber.includes('+')) {
                const [countryCode, ...numberParts] = existingDriver.phoneNumber.split(' ');
                const phoneNumber = numberParts.join(' ');
                setFormData({
                    ...existingDriver,
                    countryCode: countryCode || "+1",
                    phoneNumber: phoneNumber || ""
                });
            } else {
                setFormData({
                    ...existingDriver,
                    countryCode: "+1",
                    phoneNumber: existingDriver.phoneNumber || ""
                });
            }
            setSelectedFileName(existingDriver.driverPhoto ? "Uploaded photo" : "");
        } else {
            setFormData({
                driverId: "",
                name: "",
                dateOfBirth: "",
                phoneNumber: "",
                countryCode: "+1",
                email: "",
                company: "",
               
                driversLicense: "",
            
                licenseExpiry: "",
                driverPhoto: "",
                address: "",
            });
            setSelectedFileName("");
        }
        // Reset errors and touched when opening/closing modal
        setErrors({});
        setTouched({});
    }, [existingDriver, isOpen]);

    const validateEmail = (email: string) => {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    };

    const validatePhoneNumber = (phone: string) => {
        // Basic phone validation - allows numbers and optional spaces/dashes
        const re = /^[\d\s-]{7,15}$/;
        return re.test(phone);
    };

    const validateField = (name: string, value: string) => {
        let error = '';

        if (!value) {
            if (['name', 'dateOfBirth', 'phoneNumber', 'company', 'driversLicense', 'licenseExpiry'].includes(name)) {
                error = 'This field is required';
            }
        } else {
            if (name === 'email' && value && !validateEmail(value)) {
                error = 'Please enter a valid email address';
            }
            if (name === 'phoneNumber' && !validatePhoneNumber(value)) {
                error = 'Please enter a valid phone number (7-15 digits)';
            }
            if (name === 'dateOfBirth') {
                const dob = new Date(value);
                const today = new Date();
                const age = today.getFullYear() - dob.getFullYear();
                if (dob >= today) {
                    error = 'Date of birth must be in the past';
                }
                if(age < 18){
                    error = 'Driver must be more than 18 years old';
                }
            }

            


            
            if (name === 'licenseExpiry') {
                const expiry = new Date(value);
                const today = new Date();
                if (expiry <= today) {
                    error = 'License must not be expired';
                }
            }
        }

        setErrors(prev => ({ ...prev, [name]: error }));
    };

  
const maxSizeInBytes = 1024 * 1024; // 50KB in bytes
const allowedMimeTypes = ['image/jpeg', 'image/jpg']; // Allowed file types

const handleChange = (
  e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
) => {
  const { name, value } = e.target;
  setFormData((prev) => ({ ...prev, [name]: value }));

  // Validate on change if the field has been touched
  if (touched[name]) {
    validateField(name, value);
  }

  if (e.target instanceof HTMLInputElement) {
    if (e.target.type === 'file') {
      const files = e.target.files;
      const file = files ? files[0] : null;

      if (file) {
        // File Type Validation
        if (!allowedMimeTypes.includes(file.type)) {
          alert(`${name === 'driverPhoto' } must be a .jpg or .jpeg file.`);
          e.target.value = ''; // Reset the file input
          setFormData(prevData => ({
            ...prevData,
            [name]: null,
          }));
          return;
        }

        // File Size Validation
        if (file.size > maxSizeInBytes) {
          alert(`${name === 'driverPhoto'} size exceeds 1 MB. Please choose a smaller file.`);
          e.target.value = ''; // Reset the file input
          setFormData(prevData => ({
            ...prevData,
            [name]: null,
          }));
        } else {
          setFormData(prevData => ({
            ...prevData,
            [name]: file,
          }));
        }
      }
    }
  }
};

// Remove the duplicate declaration of allowedMimeTypes that was here
    const handleBlur = (e: React.FocusEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setTouched(prev => ({ ...prev, [name]: true }));
        validateField(name, value);
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            setSelectedFileName(file.name);
            const reader = new FileReader();
            reader.onloadend = () => {
                setFormData(prev => ({ ...prev, driverPhoto: reader.result as string }));
            };
            reader.readAsDataURL(file);
        }
    };

    const handleRemoveFile = () => {
        setSelectedFileName("");
        setFormData(prev => ({ ...prev, driverPhoto: "" }));
    };

    const validateForm = () => {
        const newErrors: Record<string, string> = {};
        const requiredFields = ['name', 'dateOfBirth', 'phoneNumber', 'company', 'driversLicense', 'licenseExpiry'];

        // Validate required fields
        requiredFields.forEach(field => {
            if (!formData[field as keyof Driver]) {
                newErrors[field] = 'This field is required';
            }
        });

        // Validate email if provided
        if (formData.email && !validateEmail(formData.email)) {
            newErrors.email = 'Please enter a valid email address';
        }

        // Validate phone number
        if (!validatePhoneNumber(formData.phoneNumber)) {
            newErrors.phoneNumber = 'Please enter a valid phone number (7-15 digits)';
        }

        // Validate dates
        const today = new Date();
        const dob = new Date(formData.dateOfBirth);
        if (dob >= today) {
            newErrors.dateOfBirth = 'Date of birth must be in the past';
        }

        const expiry = new Date(formData.licenseExpiry);
        if (expiry <= today) {
            newErrors.licenseExpiry = 'License must not be expired';
        }

        setErrors(newErrors);
        setTouched(prev => {
            const newTouched = { ...prev };
            requiredFields.forEach(field => {
                newTouched[field] = true;
            });
            if (formData.email) newTouched.email = true;
            newTouched.phoneNumber = true;
            return newTouched;
        });

        return Object.keys(newErrors).length === 0;
    };

    const getInputClass = (name: string) => {
        return `w-full border p-2 rounded focus:ring-2 focus:ring-blue-500 ${touched[name] && errors[name] ? 'border-red-500' : 'border-gray-300'
            }`;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!validateForm()) {
            return;
        }

        setIsSubmitting(true);

        
        try {
            // Combine country code and phone number before saving
            const driverData = {
                ...formData,
                phoneNumber: `${formData.countryCode} ${formData.phoneNumber}`
            };

            let savedDriver;
            if (existingDriver) {
                savedDriver = await updateDriver(existingDriver.driverId, driverData);
                toast.success("Driver updated successfully!");
            } else {
                savedDriver = await addDriver(driverData);
                toast.success("Driver added successfully!");
            }
            onSave(savedDriver);
            onClose();
        } catch (error) {
            console.error("Error saving driver:", error);
            toast.error("Failed to save driver. Please try again.");
        } finally {
            setIsSubmitting(false);
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 flex items-center justify-center bg-black/75 z-50">
            <div className="bg-white p-6 rounded-lg shadow-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                <h2 className="text-xl font-semibold mb-4">
                    {existingDriver ? "Edit Driver" : "Add New Driver"}
                </h2>
                <form onSubmit={handleSubmit}>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Name Field */}
                        <div className="space-y-2">
                            <label className="block text-sm font-medium text-gray-700">Name *</label>
                            <input
                                type="text"
                                name="name"
                                value={formData.name}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                className={getInputClass('name')}
                            />
                            {touched.name && errors.name && (
                                <p className="text-red-500 text-xs mt-1">{errors.name}</p>
                            )}
                        </div>

                        {/* Date of Birth Field */}
                        <div className="space-y-2">
                            <label className="block text-sm font-medium text-gray-700">Date of Birth *</label>
                            <input
                                type="date"
                                name="dateOfBirth"
                                value={formData.dateOfBirth}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                className={getInputClass('dateOfBirth')}
                            />
                            {touched.dateOfBirth && errors.dateOfBirth && (
                                <p className="text-red-500 text-xs mt-1">{errors.dateOfBirth}</p>
                            )}
                        </div>

                        {/* Phone Number Field - Split into country code and number */}
                         <div className="space-y-2">
                            <label className="block text-sm font-medium text-gray-700">Phone Number *</label>
                            <div className="flex gap-2">
                                <div className="flex-1">
                                    <select
                                        name="countryCode"
                                        value={formData.countryCode}
                                        onChange={handleChange}
                                        className="w-full border p-2 rounded focus:ring-2 focus:ring-blue-500 border-gray-300"
                                    >
                                        <option value="+1">+1 (US)</option>
                                        <option value="+44">+44 (UK)</option>
                                        <option value="+91">+91 (IN)</option>
                                        <option value="+61">+61 (AU)</option>
                                        <option value="+33">+33 (FR)</option>
                                        <option value="+49">+49 (DE)</option>
                                        <option value="+81">+81 (JP)</option>
                                        <option value="+86">+86 (CN)</option>
                                    </select>
                                </div>
                                <div className="flex-2">
                                    <input
                                        type="tel"
                                        name="phoneNumber"
                                        value={formData.phoneNumber}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        className={getInputClass('phoneNumber')}
                                        placeholder="e.g. 5551234567"
                                    />
                                    {touched.phoneNumber && errors.phoneNumber && (
                                        <p className="text-red-500 text-xs mt-1">{errors.phoneNumber}</p>
                                    )}
                                </div>
                            </div>
                        </div>

                        
                        {/* Email Field */}
                        <div className="space-y-2">
                            <label className="block text-sm font-medium text-gray-700">Email address</label>
                            <input
                                type="email"
                                name="email"
                                value={formData.email}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                className={getInputClass('email')}
                                placeholder="example@domain.com"
                            />
                            {touched.email && errors.email && (
                                <p className="text-red-500 text-xs mt-1">{errors.email}</p>
                            )}
                        </div>

                        {/* Company Field */}
                        <div className="space-y-2">
                            <label className="block text-sm font-medium text-gray-700">Company *</label>
                            <select
                                name="company"
                                value={formData.company}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                className={getInputClass('company')}
                            >
                                <option value="">Select Company</option>
                                <option value="Company A">Company A</option>
                                <option value="Company B">Company B</option>
                            </select>
                            {touched.company && errors.company && (
                                <p className="text-red-500 text-xs mt-1">{errors.company}</p>
                            )}
                        </div>

                        

                        {/* Driver's License Field */}
                        <div className="space-y-2">
                            <label className="block text-sm font-medium text-gray-700">Driver's License # *</label>
                            <input
                                type="text"
                                name="driversLicense"
                                value={formData.driversLicense}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                className={getInputClass('driversLicense')}
                            />
                            {touched.driversLicense && errors.driversLicense && (
                                <p className="text-red-500 text-xs mt-1">{errors.driversLicense}</p>
                            )}
                        </div>

                        

                        {/* License Expiry Field */}
                        <div className="space-y-2">
                            <label className="block text-sm font-medium text-gray-700">License Expiry Date *</label>
                            <input
                                type="date"
                                name="licenseExpiry"
                                value={formData.licenseExpiry}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                className={getInputClass('licenseExpiry')}
                            />
                            {touched.licenseExpiry && errors.licenseExpiry && (
                                <p className="text-red-500 text-xs mt-1">{errors.licenseExpiry}</p>
                            )}
                        </div>

                        {/* Address Field */}
                        <div className="space-y-2">
                            <label className="block text-sm font-medium text-gray-700">Driver Address</label>
                            <input
                                type="text"
                                name="address"
                                value={formData.address}
                                onChange={handleChange}
                                onBlur={handleBlur}
                                className="w-full border p-2 rounded focus:ring-2 focus:ring-blue-500 border-gray-300"
                            />
                        </div>

                        {/* Driver Photo Field */}
                        <div className="space-y-2 ">
                            <label className="block text-sm font-medium text-gray-700">Driver Photo</label>
                            {!selectedFileName ? (
                                <input
                                    type="file"
                                    name="driverPhoto"
                                    onChange={handleChange}
                                    className="w-full border p-2 rounded focus:ring-2 focus:ring-blue-500 border-gray-300"
                                    accept="image/*"
                                />
                            ) : (
                                <div className="flex items-center justify-between p-2 border rounded bg-gray-50">
                                    <span className="text-sm text-gray-700 truncate">{selectedFileName}</span>
                                    <button
                                        type="button"
                                        onClick={handleRemoveFile}
                                        className="ml-2 text-red-500 hover:text-red-700"
                                    >
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                            <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                                        </svg>
                                    </button>
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="flex justify-end space-x-3 mt-6">
                        <button
                            type="button"
                            className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400 transition-colors"
                            onClick={onClose}
                            disabled={isSubmitting}
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors disabled:bg-blue-400"
                            disabled={isSubmitting}
                        >
                            {isSubmitting ? (
                                <span className="flex items-center">
                                    <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                    </svg>
                                    {existingDriver ? "Updating..." : "Adding..."}
                                </span>
                            ) : (
                                existingDriver ? "Update Driver" : "Add Driver"
                            )}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default DriverFormModal;
