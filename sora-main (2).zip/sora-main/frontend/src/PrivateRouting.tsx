// ProtectedRoute.tsx
import { Navigate } from "react-router-dom";

const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
    const token = localStorage.getItem("token");

    if (!token) {
        // Clear any existing active section
        localStorage.removeItem("activeSection");
        return <Navigate to="/" replace />;
    }

    return children;
};

export default ProtectedRoute;