import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import PageLogin from "./pages/Login"; // Login from pages
import FleetOperator from "./pages/FleetOperator";
import Map from "./components/Map";
import CalendarTimePicker from "./components/CalendarTimePicker";
import DemoMap from "./components/DemoMap";
import AdminPage from "./pages/Admin";
import FleetOperatorForm from "./components/FleetOperatorFormModal";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<PageLogin />} />  {/* Uses pages/Login */}
        <Route path="/fleet-operator" element={<FleetOperator />} /> {/* Uses components/Login */}
        <Route path="/Map" element={<Map />} />
        <Route path="/DMap" element={<DemoMap />} />
        <Route path="/Admin" element={<AdminPage />} />
        <Route path="/form" element={<FleetOperatorForm />} />
        <Route path="/cal" element={<CalendarTimePicker onClose={function (): void {
          throw new Error("Function not implemented.");
        }} />} />
      </Routes>
    </Router>
  );
}

export default App;
