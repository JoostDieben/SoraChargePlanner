import axios from "axios";
import { Vehicle } from "../types/vehicleTypes"; // Ensure this matches the Vehicle interface

const API_BASE_URL = "/api/vehicles"; // Adjust if needed


export const createVehicle = async (vehicle: Omit<Vehicle, "vehicleId">) => {
    const fleetManagerId = localStorage.getItem("userId"); // Retrieve user ID

    if (!fleetManagerId) {
        throw new Error("Fleet Manager ID is missing. User might not be logged in.");
    }

    const response = await axios.post(`${API_BASE_URL}`, {
        ...vehicle,
        fleetManagerId: parseInt(fleetManagerId), // Convert to number if needed
    });

    return response.data;
};

export const getAllVehicles = async () => {
    const response = await axios.get(`${API_BASE_URL}`);
    return response.data;
};

export const getVehicleById = async (vehicleId: string) => {
    const response = await axios.get(`${API_BASE_URL}/${vehicleId}`);
    return response.data;
};

export const updateVehicle = async (vehicleId: string, vehicle: Partial<Vehicle>) => {
    const fleetManagerId = localStorage.getItem("userId"); // Retrieve fleet manager ID

    if (!fleetManagerId) {
        throw new Error("Fleet Manager ID is missing. User might not be logged in.");
    }

    const response = await axios.put(`${API_BASE_URL}/${vehicleId}`, {
        ...vehicle,
        fleetManagerId: parseInt(fleetManagerId), // Ensure it's included
    });

    return response.data;
};

export const deleteVehicle = async (vehicleId: string) => {
    await axios.delete(`${API_BASE_URL}/${vehicleId}`);
};
