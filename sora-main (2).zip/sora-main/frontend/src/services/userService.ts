import axios from "axios";

const API_URL = "/api/users"; // Change to your backend URL


export const loginUser = async (email: string, password: string) => {
  try {
    const response = await axios.post(`${API_URL}/login`, { email, password });
    return response.data;
  } catch (error: any) {
    throw error.response?.data || { message: "Something went wrong" };
  }
};
export const fetchUser = async (userId: string) => {
  try {
      const response = await fetch(`/api/users/${userId}`, {
          method: "GET",
          credentials: "include", // If using cookies for authentication
      });

      const data = await response.json();

      if (!response.ok) {
          throw new Error(data.message || "Failed to fetch user");
      }

      return data;
  } catch (error) {
      console.error("Error fetching user:", error);
      throw error;
  }
};
