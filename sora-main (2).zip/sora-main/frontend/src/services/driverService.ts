import axios from "axios";
import { Driver } from "../types/driverTypes"; // Ensure this matches the Driver interface


const API_BASE_URL = "/api/drivers"; // Adjust if needed

export const addDriver = async (driver: Omit<Driver, "driverId">) => {
    const fleetManagerId = localStorage.getItem("userId"); // Retrieve user ID

    if (!fleetManagerId) {
        throw new Error("Fleet Manager ID is missing. User might not be logged in.");
    }

    const response = await axios.post(`${API_BASE_URL}/add`, {
        ...driver,
        fleetManagerId: parseInt(fleetManagerId), // Convert to number if needed
    });

    return response.data;
};


export const getAllDrivers = async () => {
    const response = await axios.get(`${API_BASE_URL}/all`);
    return response.data;
};

export const getDriverById = async (driverId: string) => {
    const response = await axios.get(`${API_BASE_URL}/${driverId}`);
    return response.data;
};

export const updateDriver = async (driverId: string, driver: Partial<Driver>) => {
    const fleetManagerId = localStorage.getItem("userId"); // Retrieve fleet manager ID

    if (!fleetManagerId) {
        throw new Error("Fleet Manager ID is missing. User might not be logged in.");
    }

    const response = await axios.put(`${API_BASE_URL}/${driverId}`, {
        ...driver,
        fleetManagerId: parseInt(fleetManagerId), // Ensure it's included
    });

    return response.data;
};


export const deleteDriver = async (driverId: string) => {
    await axios.delete(`${API_BASE_URL}/drive/${driverId}`);
};

