export const logoutUser = () => {
    // Clear all user-related data
    localStorage.removeItem("token");
    localStorage.removeItem("userId");
    localStorage.removeItem("activeSection");

    // Clear session storage if used
    sessionStorage.clear();

    // Clear any cookies if used
    document.cookie.split(";").forEach((c) => {
        document.cookie = c
            .replace(/^ +/, "")
            .replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/");
    });
};