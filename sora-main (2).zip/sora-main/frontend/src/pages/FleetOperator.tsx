import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Sidebar from "../components/Sidbar";
import OrdersTable from "../components/OrderTable";
import DriverTable from "../components/DriverTable";
import VehicleTable from "../components/VehicleTable";
import { fetchUser } from "../services/userService";
import { logoutUser } from "../services/logoutService";
import { FiPackage, FiUser, FiCalendar } from "react-icons/fi";
import { FaMoneyBillWave, FaTruckMoving } from "react-icons/fa";
import { IoPeopleSharp } from "react-icons/io5";

const FleetOperator: React.FC = () => {
    const [activeSection, setActiveSection] = useState<string>(
        localStorage.getItem("activeSection") || "Orders"
    );
    const [user, setUser] = useState<any>(null);
    const [drivers, setDrivers] = useState<any[]>([]);
    const [vehicles, setVehicles] = useState<any[]>([]);
    const [orders, setOrders] = useState<any[]>([]);
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const navigate = useNavigate();

    // Store active section in localStorage whenever it changes
    useEffect(() => {
        localStorage.setItem("activeSection", activeSection);
    }, [activeSection]);

    const getUser = async () => {
        const userId = localStorage.getItem("userId");
        if (!userId) {
            handleLogout();
            return;
        }

        try {
            const userData = await fetchUser(userId);
            setUser(userData);
        } catch (error) {
            console.error("Failed to fetch user:", error);
            handleLogout();
        }
    };

    const fetchDrivers = async () => {
        try {
            const response = await fetch("/api/drivers/all");
            const data = await response.json();
            if (response.ok) {
                setDrivers(data);
            } else {
                console.error("Failed to fetch drivers:", data.message);
            }
        } catch (error) {
            console.error("Error fetching drivers:", error);
        }
    };

    const fetchVehicles = async () => {
        try {
            const response = await fetch("/api/vehicles");
            const data = await response.json();
            if (response.ok) {
                setVehicles(Array.isArray(data) ? data : []);
            } else {
                console.error("Failed to fetch Vehicles:", data.message);
                setVehicles([]);
            }
        } catch (error) {
            console.error("Error fetching Vehicles:", error);
            setVehicles([]);
        }
    };

    const fetchOrders = async () => {
        try {
            const response = await fetch("/api/orders");
            const data = await response.json();
            if (response.ok) {
                setOrders(Array.isArray(data) ? data : []);
            } else {
                console.error("Failed to fetch Orders:", data.message);
                setOrders([]);
            }
        } catch (error) {
            console.error("Error fetching Orders:", error);
            setOrders([]);
        }
    };

    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            try {
                await Promise.all([getUser(), fetchDrivers(), fetchVehicles(), fetchOrders()]);
            } catch (error) {
                setError("Failed to fetch data");
                console.error(error);
            } finally {
                setIsLoading(false);
            }
        };

        fetchData();
    }, []);

    const handleLogout = () => {
        logoutUser();
        navigate("/");
    };

    const menuItems = [
        { name: "Orders", icon: <FiPackage /> },
        { name: "Drivers", icon: <IoPeopleSharp /> },
        { name: "Vehicle", icon: <FaTruckMoving /> },
        { name: "Charge Expense", icon: <FaMoneyBillWave /> },
        { name: "Profile", icon: <FiUser /> },
    ];

    const handleSaveOrder = (newOrder: any) => {
        setOrders((prevOrders) => [...prevOrders, newOrder]);
    };

    const handleDriverAdded = (newDriver: any) => {
        setDrivers((prevDrivers) => [...prevDrivers, newDriver]);
    };

    const handleVehicleAdded = (newVehicle: any) => {
        setVehicles((prevVehicles) => [...prevVehicles, newVehicle]);
    };

    if (isLoading) {
        return (
            <div className="flex items-center justify-center h-screen">
                <div className="text-xl font-semibold">Loading...</div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="flex items-center justify-center h-screen">
                <div className="text-xl font-semibold text-red-500">Error: {error}</div>
            </div>
        );
    }

    return (
        <div className="flex">
            <Sidebar
                activeSection={activeSection}
                setActiveSection={setActiveSection}
                menuItems={menuItems}
            />
            <div className="flex-1 p-6 bg-gray-100 h-screen overflow-auto">
                {activeSection === "Orders" && <OrdersTable orders={orders} onSave={handleSaveOrder} />}
                {activeSection === "Drivers" && (
                    <DriverTable
                        drivers={drivers}
                        onDriverAdded={handleDriverAdded}
                        refreshDrivers={fetchDrivers}
                    />
                )}
                {activeSection === "Vehicle" && Array.isArray(vehicles) && (
                    <VehicleTable
                        vehicles={vehicles}
                        onVehicleAdded={handleVehicleAdded}
                        refreshVehicles={fetchVehicles}
                    />
                )}
                {activeSection === "Profile" && user && (
                    <div className="bg-white p-6 rounded-lg shadow">
                        <h2 className="text-xl font-semibold mb-4">User Profile</h2>
                        <p><strong>Name:</strong> {user.name}</p>
                        <p><strong>Email:</strong> {user.email}</p>
                        <p><strong>Role:</strong> {user.role}</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default FleetOperator;
