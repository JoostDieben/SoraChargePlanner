import React, { useState, useEffect } from "react";
import Sidebar from "../components/Sidbar";
import { FiPackage, FiUser } from "react-icons/fi";
import { FaMoneyBillWave, FaTruckMoving } from "react-icons/fa";
import { IoPeopleSharp } from "react-icons/io5";
import FleetPartner from "../components/FleetPartner";

const AdminPage: React.FC = () => {
    // Set "dashboard" as the default if no value is stored
    const storedSection = typeof localStorage !== "undefined" ? localStorage.getItem("activeSection") : null;
    const [activeSection, setActiveSection] = useState<string>(storedSection || "dashboard");

    useEffect(() => {
        localStorage.setItem("activeSection", activeSection);
    }, [activeSection]);

    const menuItems = [
        { name: "dashboard", icon: <FiPackage /> },
        { name: "site partner", icon: <IoPeopleSharp /> },
        { name: "fleet-operator", icon: <FaTruckMoving /> },
        { name: "Charge Expense", icon: <FaMoneyBillWave /> },
        { name: "Profile", icon: <FiUser /> },
    ];

    return (
        <div className="flex">
            <Sidebar
                activeSection={activeSection}
                setActiveSection={setActiveSection}
                menuItems={menuItems}
            />
            <div className="flex-1 p-6 bg-gray-100 h-screen overflow-auto">
                {activeSection === "dashboard" && (
                    <div>
                        <h1 className="text-2xl font-bold mb-4">Welcome to Dashboard</h1>
                        <p>No data available</p>
                    </div>
                )}
                {activeSection === "site partner" && (
                    <div>
                        <h1 className="text-2xl font-bold mb-4">Welcome to Site Partner</h1>
                        <p>No data available</p>
                    </div>
                )}
                {activeSection === "fleet-operator" && (
                    <div>
                        <FleetPartner />
                    </div>
                )}
                {activeSection === "Charge Expense" && (
                    <div>
                        <h1 className="text-2xl font-bold mb-4">Welcome to Charge Expense</h1>
                        <p>No data available</p>
                    </div>
                )}
                {activeSection === "Profile" && (
                    <div>
                        <h1 className="text-2xl font-bold mb-4">Welcome to Profile</h1>
                        <div className="flex items-center space-x-4">
                            <img
                                src="https://via.placeholder.com/150"
                                alt="Admin"
                                className="w-24 h-24 rounded-full"
                            />
                            <div>
                                <p className="text-lg font-semibold">John Doe</p>
                                <p className="text-sm text-gray-600">john.doe@example.com</p>
                                <p className="text-sm text-gray-600">+1 234 567 890</p>
                            </div>
                        </div>
                        <div className="mt-4">
                            <p className="text-gray-700">Role: Admin</p>
                            <p className="text-gray-700">Joined: January 2023</p>
                        </div>
                        <button className="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
                            Reset Password
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default AdminPage;
