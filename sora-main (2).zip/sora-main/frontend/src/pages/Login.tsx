"use client";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { loginUser } from "../services/userService";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Login = () => {
  const [email, setEmail] = useState(localStorage.getItem("rememberedEmail") || "");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(localStorage.getItem("rememberedEmail") ? true : false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  setLoading(true);

  try {
    const data = await loginUser(email, password);
    console.log("Login Successful:", data);

    localStorage.setItem("token", data.token);
    localStorage.setItem("userId", data.user.id);

    if (rememberMe) {
      localStorage.setItem("rememberedEmail", email);
    } else {
      localStorage.removeItem("rememberedEmail");
    }

    // Set default active section to "Orders"
    localStorage.setItem("activeSection", "Orders");

    toast.success("Login successful! Redirecting...", {
      position: "top-right",
      autoClose: 2000,
    });

    setTimeout(() => navigate("/fleet-operator"), 2000);
  } catch (err: any) {
    toast.error(err.message || "Invalid email or password", {
      position: "top-right",
      autoClose: 3000,
    });
  } finally {
    setLoading(false);
  }
};


  return (
    <div className="relative flex flex-col items-center w-full h-screen">
      <ToastContainer />
      <div className="absolute top-[125px] left-1/2 transform -translate-x-1/2 w-[150px] h-[150px] z-10">
        <img src="/images/soraLogoTwo.png" alt="Orange Circle" className="w-full h-full" />
      </div>

      <div className="flex w-full h-full flex-col md:flex-row">
        <div className="w-full md:w-1/2 flex items-center justify-center bg-gray-100">
          <div className="w-full max-w-md rounded-lg bg-white p-8 shadow-lg">
            <div className="flex justify-center mb-6">
              <img src="/images/soraLogoOne.png" alt="Sora Energy" width={120} height={40} />
            </div>
            <h2 className="text-center text-2xl font-semibold mb-4">Welcome back! ✨</h2>
            <form className="space-y-4" onSubmit={handleSubmit}>
              <div>
                <label className="block text-gray-700">Email Address</label>
                <input
                  type="email"
                  className="w-full mt-1 p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-gray-700">Password</label>
                <input
                  type="password"
                  className="w-full mt-1 p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              <div className="flex items-center justify-between">
                <label className="flex items-center text-gray-700">
                  <input
                    type="checkbox"
                    className="mr-2"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                  />
                  Remember me
                </label>
                <a href="#" className="text-blue-500 text-sm">Forgot Password?</a>
              </div>
              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition"
                disabled={loading}
              >
                {loading ? "Signing In..." : "Sign In"}
              </button>
            </form>
            <p className="mt-4 text-center text-sm text-gray-600">
              Trouble with your account? <a href="#" className="text-blue-500">Connect with admin</a>
            </p>
            <div className="mt-4 p-3 text-sm bg-yellow-100 text-yellow-700 rounded-md flex items-center">
              <span>⚠️ Sora Energy will have a planned update on Dec 2, from 00:00-2:00pm CET.</span>
            </div>
          </div>
        </div>

        <div className="w-full md:w-1/2 bg-gray-200 flex items-center justify-center">
          <img src="/images/loginRightImg.png" alt="Login Illustration" className="w-full h-full object-cover" />
        </div>
      </div>
    </div>
  );
};

export default Login;
