import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import path from 'path';
import sequelize from "./config/db";
import userRoutes from "./routes/userRoutes";
import driverRoutes from "./routes/driverRoutes";
import vehicleRoutes from "./routes/vehicleRoutes";
import orderRoutes from "./routes/orderRoutes";
import reservationRoutes from "./routes/reservationRoutes";


dotenv.config();
const app = express();
const port = process.env.PORT || 5000;

app.use(express.static(path.join("/home/ubuntu/sora/frontend/dist")));
app.get("/", (req, res) => {
  res.sendFile(path.join("/home/ubuntu/sora/frontend/dist/index.html"));
});
app.get("/DMap", (req, res) => {
  res.sendFile(path.join("/home/ubuntu/sora/frontend/dist/index.html"));
});
app.get("/fleet-operator", (req, res) => {
  res.sendFile(path.join("/home/ubuntu/sora/frontend/dist/index.html"));
});

app.use(express.json());
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET,HEAD,PUT,PATCH,POST,DELETE');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  next();
});
app.use("/api/users", userRoutes);
app.use("/api/drivers", driverRoutes);
app.use("/api/vehicles", vehicleRoutes);
app.use("/api/orders", orderRoutes);
app.use("/api/reservations", reservationRoutes);

sequelize
  .sync()
  .then(() => console.log("✅ Database Synced"))
  .catch((err) => console.error("❌ Database Sync Error:", err));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
