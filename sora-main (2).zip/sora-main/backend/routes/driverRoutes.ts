
import express from "express";
import { createDriver, getAllDrivers, getDriverById, updateDriver, deleteDriver, getDriversByFleetManager } from "../controllers/driverController";

const router = express.Router();

router.post("/add", createDriver);
router.get("/all", getAllDrivers);
router.get("/:driverId", getDriverById);
router.put("/:driverId", updateDriver);
router.delete("/:driverId", deleteDriver);
router.get("/fleetManager/:fleetManagerId", getDriversByFleetManager);



export default router;
