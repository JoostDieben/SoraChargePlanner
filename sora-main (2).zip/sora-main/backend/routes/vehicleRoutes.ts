import { Router } from "express";
import { createVehicle, getAllVehicles, getVehicleById, updateVehicle, deleteVehicle, getVehiclesByFleetManager } from "../controllers/vehicleController";

const router = Router();

// Define routes correctly
router.post("/", createVehicle); // Create a new vehicle
router.get("/", getAllVehicles); // Get all vehicles
router.get("/:vehicleId", getVehicleById); // Get a vehicle by ID
router.put("/:vehicleId", updateVehicle); // Update vehicle details
router.delete("/:vehicleId", deleteVehicle); // Delete a vehicle
router.get("/fleetManager/:fleetManagerId", getVehiclesByFleetManager);
export default router;