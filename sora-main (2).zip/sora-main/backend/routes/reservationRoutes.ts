import express from "express";
import {
    createReservation,
    listReservations,
    getReservation,
    cancelReservation,
  
} from "../controllers/reservationController";

const router = express.Router();

// ✅ Create a new reservation
router.post("/", createReservation);

// ✅ List all reservations with filtering & pagination
router.get("/", listReservations);

// ✅ Get a single reservation by ID
router.get("/:OrderId", getReservation);

// ✅ Cancel (delete) a reservation
router.delete("/:id", cancelReservation);

// ✅ Update a reservation (delete old, create new)



export default router;
