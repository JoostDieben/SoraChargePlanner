import { DataTypes, Model, Optional } from "sequelize";
import sequelize from "../config/db";
import Driver from "./Driver";
import Vehicle from "./Vehicle";
import {User} from "./User";

interface OrderAttributes {
    OrderId: string;
    name: string;
    quantity: number;
    route: string;
    startLocation: string;
    endLocation: string;
    customer: string;
    items: string;
    weight: string;
    startDateTime: string;
    endDateTime: string;
    tripType: string;
    type: string;
    operatingDays: string;
    fleetManagerId: number;
    driverId: string;
    vehicleId: number;
}

export interface OrderCreationAttributes extends Optional<OrderAttributes, 'OrderId'> {}

class Order extends Model<OrderAttributes, OrderCreationAttributes> implements OrderAttributes {
    public OrderId!: string;
    public name!: string;
    public quantity!: number;
    public route!: string;
    public startLocation!: string;
    public endLocation!: string;
    public customer!: string;
    public items!: string;
    public weight!: string;
    public startDateTime!: string;
    public endDateTime!: string;
    public tripType!: string;
    public type!: string;
    public operatingDays!: string;
    public fleetManagerId!: number;
    public driverId!: string;
    public vehicleId!: number;
}

Order.init(
    {
        OrderId: {
            type: DataTypes.STRING,
            allowNull: false,
            primaryKey: true,
            defaultValue: () => `ORDER-${Math.floor(Math.random() * 1000000)}`,
        },
        name: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        quantity: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        route: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        startLocation: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        endLocation: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        customer: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        items: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        weight: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        startDateTime: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        endDateTime: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        tripType: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        type: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        operatingDays: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        fleetManagerId: {
            type: DataTypes.INTEGER,
            allowNull: false,
            references: {
                model: User,
                key: "id",
            },
            onUpdate: "CASCADE",
            onDelete: "CASCADE",
        },
        driverId: {
            type: DataTypes.STRING,
            allowNull: false,
            references: {
                model: Driver,
                key: "driverId",
            },
            onUpdate: "CASCADE",
            onDelete: "CASCADE",
        },
        vehicleId: {
            type: DataTypes.INTEGER,
            allowNull: false,
            references: {
                model: Vehicle,
                key: "vehicleId",
            },
            onUpdate: "CASCADE",
            onDelete: "CASCADE",
        },
    },
    {
        sequelize,
        tableName: "orders",
        timestamps: true,
    }
);

// Associations
Order.belongsTo(User, { foreignKey: "fleetManagerId", as: "fleetManager" });
Order.belongsTo(Driver, { foreignKey: "driverId", as: "driver" });
Order.belongsTo(Vehicle, { foreignKey: "vehicleId", as: "vehicle" });

export default Order;
