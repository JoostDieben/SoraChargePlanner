import { DataTypes, Model } from "sequelize";
import sequelize from "../config/db";
import { User } from "./User";

interface DriverAttributes {
    driverId: string;
    name: string;
    dateOfBirth: string;
    phoneNumber: string;
    email: string;
    company: string;
   
    driversLicense: string;
  
    licenseExpiry: string;
    driverPhoto?: Buffer | null;
    address: string;
    fleetManagerId: number;
}

class Driver extends Model<DriverAttributes> implements DriverAttributes {
    public driverId!: string;
    public name!: string;
    public dateOfBirth!: string;
    public phoneNumber!: string;
    public email!: string;
    public company!: string;
   
    public driversLicense!: string;

    public licenseExpiry!: string;
    public driverPhoto?:Buffer | null;
    public address!: string;
    public fleetManagerId!: number;
}

Driver.init(
    {
        driverId: {
            type: DataTypes.STRING,  // Change from UUID to STRING
            allowNull: false,
            primaryKey: true,
        },
        name: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        dateOfBirth: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        phoneNumber: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        email: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true,
        },
        company: {
            type: DataTypes.STRING,
            allowNull: false,
        },
       
        driversLicense: {
            type: DataTypes.STRING,
            allowNull: false,
        },
      
        licenseExpiry: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        driverPhoto: {
            type: DataTypes.BLOB('long'),
            allowNull: true,
        },
        address: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        fleetManagerId: {
            type: DataTypes.INTEGER,
            allowNull: false,
            references: {
                model: User,
                key: "id",
            },
            onUpdate: "CASCADE",
            onDelete: "CASCADE",
        },
    },
    {
        sequelize,
        tableName: "drivers",
        timestamps: true,
    }
);

Driver.belongsTo(User, { foreignKey: "fleetManagerId", as: "fleetManager" });
User.hasMany(Driver, { foreignKey: "fleetManagerId", as: "drivers" });

export default Driver;
