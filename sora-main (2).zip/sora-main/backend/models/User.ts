import { DataTypes, Model } from 'sequelize';
import sequelize from '../config/db';

interface UserAttributes {
  id?: number;
  email: string;
  password: string;
  name: string;
  phoneNumber: string;
  role: 'Fleet User' | 'Admin' | 'Site Partner';
  isActive: boolean;
  profileImage?: string | null;
}

class User extends Model<UserAttributes> implements UserAttributes {
  public id!: number;
  public email!: string;
  public password!: string;
  public name!: string;
  public phoneNumber!: string;
  public role!: 'Fleet User' | 'Admin' | 'Site Partner';
  public isActive!: boolean;
  public profileImage?: string | null;
}

User.init(
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    phoneNumber: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    role: {
      type: DataTypes.ENUM('Fleet User', 'Admin', 'Site Partner'), // Restrict values
      allowNull: false,
      defaultValue: 'Fleet User',
    },
    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
    profileImage: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  },
  {
    sequelize,
    tableName: 'users',
    timestamps: true,
  }
);

export { User };
