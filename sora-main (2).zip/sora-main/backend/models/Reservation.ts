import { DataTypes, Model, Optional } from "sequelize";
import sequelize from "../config/db";
import { User } from "./User";
import Order from "./Order";

interface ReservationAttributes {
    id: string; // Changed to UUID from the API response
    fleetManagerId: number;
    OrderId: string;
    connector: string;
    charger: string; // Added charger field from API response
    duration: number;
    start_date_time: Date;
    end_date_time: Date;
    rate: number;
    source_id: string;
    status: string;
    ocpp_reservation_id: string; // Added field
    id_token: string; // Added field
    created_at: Date; // Added field
    updated_at: Date; // Added field
    expiry_datetime: Date; // Added field
    timezone: string;
}

export interface ReservationCreationAttributes extends Optional<ReservationAttributes, 'id' | 'source_id' | 'status' | 'ocpp_reservation_id' | 'id_token' | 'charger' | 'created_at' | 'updated_at' | 'expiry_datetime'> {}

class Reservation extends Model<ReservationAttributes, ReservationCreationAttributes> implements ReservationAttributes {
    public id!: string;
    public fleetManagerId!: number;
    public OrderId!: string;
    public connector!: string;
    public charger!: string;
    public duration!: number;
    public start_date_time!: Date;
    public end_date_time!: Date;
    public rate!: number;
    public source_id!: string;
    public status!: string;
    public ocpp_reservation_id!: string;
    public id_token!: string;
    public created_at!: Date;
    public updated_at!: Date;
    public expiry_datetime!: Date;
    public timezone!: string;
}

Reservation.init(
    {
        id: {
            type: DataTypes.UUID,
            primaryKey: true,
            allowNull: false,
        },
        fleetManagerId: {
            type: DataTypes.INTEGER,
            allowNull: false,
            references: {
                model: User,
                key: "id",
            },
            onUpdate: "CASCADE",
            onDelete: "CASCADE",
        },
        OrderId: {
            type: DataTypes.STRING,
            allowNull: false,
            references: {
                model: Order,
                key: "OrderId",
            },
            onUpdate: "CASCADE",
            onDelete: "CASCADE",
        },
        connector: {
            type: DataTypes.UUID,
            allowNull: false,
        },
        charger: {
            type: DataTypes.UUID,
            allowNull: false, // Added charger field
        },
        duration: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        start_date_time: {
            type: DataTypes.DATE,
            allowNull: false,
        },
        end_date_time: {
            type: DataTypes.DATE,
            allowNull: false,
        },
        rate: {
            type: DataTypes.FLOAT,
            allowNull: false, // Ensuring proper rate storage
        },
        source_id: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        timezone: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        status: {
            type: DataTypes.ENUM("INITIATED", "ACTIVE", "COMPLETE", "INCOMPLETE", "CANCELLED", "FAILED"),
            allowNull: false,
            defaultValue: "INITIATED",
        },
        ocpp_reservation_id: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        id_token: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        created_at: {
            type: DataTypes.DATE,
            allowNull: false,
        },
        updated_at: {
            type: DataTypes.DATE,
            allowNull: false,
        },
        expiry_datetime: {
            type: DataTypes.DATE,
            allowNull: false,
        },
    },
    {
        sequelize,
        tableName: "reservations",
        timestamps: false, // Since timestamps are coming from API response
    }
);

// Define associations
Reservation.belongsTo(User, { foreignKey: "fleetManagerId", as: "fleetManager" });
Reservation.belongsTo(Order, { foreignKey: "OrderId", as: "order" });

export default Reservation;
