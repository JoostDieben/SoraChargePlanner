import { DataTypes, Model, Optional } from "sequelize";
import sequelize from "../config/db";
import { User } from "./User";

interface VehicleAttributes {
    vehicleId: number;
    vehicleName: string;
    date: string;
    vehicleNo: string;
   
    vin: string;
    batteryCapacity: string;
    dryRange: string;
    cRate: string;
    model: string;
    year: number;
    vehicleType: string;
  
    vehiclePhoto?: string | null;
    vehicleDocument?: string | null;
    fleetManagerId: number;
}

export interface VehicleCreationAttributes extends Optional<VehicleAttributes, "vehicleId"> {}

class Vehicle extends Model<VehicleAttributes, VehicleCreationAttributes> implements VehicleAttributes {
    public vehicleId!: number;
    public vehicleName!: string;
    public date!: string;
    public vehicleNo!: string;
    public vin!: string;
    public batteryCapacity!: string;
    public dryRange!: string;
    public cRate!: string;
  
    public model!: string;
    public year!: number;
    public vehicleType!: string;
  
    public vehiclePhoto?: string | null;
    public vehicleDocument?: string | null;
    public fleetManagerId!: number;
}

Vehicle.init(
    {
        vehicleId: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true,
        },
        vehicleName: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        date: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        vehicleNo: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true, // ✅ Ensure vehicle number is unique
        },
        vin: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true, // ✅ Ensure VIN is unique
        },
        batteryCapacity: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        dryRange: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        cRate: {
            type: DataTypes.STRING,
            allowNull: true,
        },
    
        model: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        year: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        vehicleType: {
            type: DataTypes.STRING,
            allowNull: false,
        },
     
        vehiclePhoto: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        vehicleDocument: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        fleetManagerId: {
            type: DataTypes.INTEGER,
            allowNull: false,
            references: {
                model: User,
                key: "id",
            },
            onUpdate: "CASCADE",
            onDelete: "CASCADE",
        },
    },
    {
        sequelize,
        tableName: "vehicles",
        timestamps: true,
    }
);

Vehicle.belongsTo(User, { foreignKey: "fleetManagerId", as: "fleetManager" });
User.hasMany(Vehicle, { foreignKey: "fleetManagerId", as: "vehicles" });

export default Vehicle;
