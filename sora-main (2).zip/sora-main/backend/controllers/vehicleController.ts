
import { Request, Response } from 'express';
import Vehicle from '../models/Vehicle';
import { Op } from 'sequelize';
import { User } from "../models/User";

// Create a new vehicle
export const createVehicle = async (req: Request, res: Response): Promise<void> => {
    try {
        const {
            vehicleName,
            date,
            vehicleNo,
            vin,
            batteryCapacity,
            dryRange,
            cRate,
    
            model,
            year,
            vehicleType,
        
            vehiclePhoto,
            vehicleDocument,
            fleetManagerId,
        } = req.body;

        // Check if a vehicle with the same vehicleNo or VIN already exists
        const existingVehicle = await Vehicle.findOne({
            where: {
                [Op.or]: [{ vehicleNo }, { vin }],
            },
        });

        if (existingVehicle) {
           res.status(400).json({
                error: "A vehicle with the same vehicle number or VIN already exists.",
            });
        }

        // Create the new vehicle
        const newVehicle = await Vehicle.create({
            vehicleName,
            date,
            vehicleNo,
            vin,
            batteryCapacity,
            dryRange,
            cRate,
           
            model,
            year,
            vehicleType,
         
            vehiclePhoto,
            vehicleDocument,
            fleetManagerId,
        });

        res.status(201).json({
            message: "Vehicle created successfully",
            vehicle: newVehicle,
        });
    } catch (error: unknown) {
        console.error("Error creating vehicle:", error);

        res.status(500).json({
            error: "Error creating vehicle",
            details: error instanceof Error ? error.message : "Unknown error",
        });
    }
};

// Get all vehicles
export const getAllVehicles = async (req: Request, res: Response): Promise<void> => {
    try {
        const vehicles = await Vehicle.findAll({
            include: [
                {
                    model: User,
                    as: 'fleetManager',
                    attributes: ['id', 'name', 'email'], // Only select necessary fields from User
                },
            ],
        });

        res.status(200).json({
            message: 'Vehicles retrieved successfully',
            vehicles,
        });
    } catch (error: unknown) {
        if (error instanceof Error) {
            console.error(error.message);
        } else {
            console.error("An unknown error occurred");
        }
    }
}; // <-- Close the getAllVehicles function here

// Get a single vehicle by ID
export const getVehicleById = async (req: Request, res: Response): Promise<void> => {
    const { vehicleId } = req.params;
    try {
        const vehicle = await Vehicle.findByPk(vehicleId, {
            include: [
                {
                    model: User,
                    as: 'fleetManager',
                    attributes: ['id', 'name', 'email'], // Only select necessary fields from User
                },
            ],
        });

        if (vehicle) {
            res.status(200).json({
                message: 'Vehicle retrieved successfully',
                vehicle,
            });
        } else {
            res.status(404).json({
                message: 'Vehicle not found',
            });
        }
    } catch (error: unknown) {
        if (error instanceof Error) {
            console.error(error.message);
        } else {
            console.error("An unknown error occurred");
        }
    }
}; // <-- Close the getVehicleById function here

// Update a vehicle by ID
export const updateVehicle = async (req: Request, res: Response): Promise<void> => {
    const { vehicleId } = req.params;
    const updateData = req.body;

    try {
        const vehicle = await Vehicle.findByPk(vehicleId);

        if (vehicle) {
            await vehicle.update(updateData);

            res.status(200).json({
                message: 'Vehicle updated successfully',
                vehicle,
            });
        } else {
            res.status(404).json({
                message: 'Vehicle not found',
            });
        }
    } catch (error: unknown) {
        if (error instanceof Error) {
            console.error(error.message);
        } else {
            console.error("An unknown error occurred");
        }
    }
}; // <-- Close the updateVehicle function here

// Delete a vehicle by ID
export const deleteVehicle = async (req: Request, res: Response): Promise<void> => {
    const { vehicleId } = req.params;

    try {
        const vehicle = await Vehicle.findByPk(vehicleId);

        if (vehicle) {
            await vehicle.destroy();

            res.status(200).json({
                message: 'Vehicle deleted successfully',
            });
        } else {
            res.status(404).json({
                message: 'Vehicle not found',
            });
        }
    } catch (error: unknown) {
        if (error instanceof Error) {
            console.error(error.message);
        } else {
            console.error("An unknown error occurred");
        }
    }
}; // <-- Close the deleteVehicle function here

// Get vehicles by fleet manager
// Add implementation here if needed
export const getVehiclesByFleetManager = async (req: Request, res: Response) : Promise<void> => {
    try {
        const { fleetManagerId } = req.params;

        if (!fleetManagerId) {
             res.status(400).json({ error: "Fleet Manager ID is required" });
        }

        const vehicle = await Vehicle.findAll({ where: { fleetManagerId } });

        if (!vehicle.length) {
             res.status(404).json({ message: "No drivers found for this Fleet Manager" });
        }

       res.status(200).json(vehicle);
    } catch (error) {
        console.error("Error fetching drivers:", error);
         res.status(500).json({ error: "Internal Server Error" });
    }
};
