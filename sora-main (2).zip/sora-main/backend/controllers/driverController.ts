import { Request, Response } from "express";
import Driver from "../models/Driver";
import multer from "multer";
import { User } from "../models/User";
const upload = multer({ storage: multer.memoryStorage() });

export const createDriver = async (req: Request, res: Response): Promise<void> => {
    try {
        upload.single("driverPhoto")(req, res, async (err) => {
            if (err) {
                console.error("[ERROR] Multer file upload error:", err);
                res.status(500).json({ error: "File upload failed" });
                return;
            }

            console.log("[DEBUG] Incoming request body:", req.body);
            console.log("[DEBUG] Uploaded file:", req.file);

            const {
                name,
                dateOfBirth,
                phoneNumber,
                email,
                company,
                
                driversLicense,
             
                licenseExpiry,
                address,
                fleetManagerId,
            } = req.body;

            // Validate required fields
            if (!email) {
                console.error("[ERROR] Email is missing.");
                res.status(400).json({ error: "Email is required" });
                return;
            }

            if (!driversLicense) {
                console.error("[ERROR] Driver's license is missing.");
                res.status(400).json({ error: "Driver's license is required" });
                return;
            }

            // Convert date fields from string to ISO format
           // Convert date fields from string to ISO format, ensuring they are strings
const parsedDateOfBirth = dateOfBirth ? new Date(dateOfBirth).toISOString() : "";
const parsedLicenseExpiry = licenseExpiry ? new Date(licenseExpiry).toISOString() : "";


            // Handle optional file upload for driverPhoto
            const driverPhoto = req.file ? req.file.buffer : null;

            // Check if email already exists
            const existingEmail = await Driver.findOne({ where: { email } });
            if (existingEmail) {
                console.error("[ERROR] Driver with this email already exists.");
                res.status(400).json({ error: "A driver with this email ID already exists." });
                return;
            }

            // Check if driver's license already exists
            const existingLicense = await Driver.findOne({ where: { driversLicense } });
            if (existingLicense) {
                console.error("[ERROR] Driver with this license already exists.");
                res.status(400).json({ error: "A driver with this driver license already exists." });
                return;
            }

            console.log("[INFO] Generating new driver ID.");
            const lastDriver = await Driver.findOne({ order: [["createdAt", "DESC"]] });

          let newDriverId = "D1"; // Default ID if no drivers exist
if (lastDriver) {
    const match = lastDriver.driverId.match(/^D(\d+)$/);
    if (match) {
        const lastIdNum = parseInt(match[1], 10);
        newDriverId = `D${lastIdNum + 1}`;
    }
}

            console.log("[DEBUG] New driver ID generated:", newDriverId);

            // Create new driver
            const newDriver = await Driver.create({
                driverId: newDriverId,
                name,
                dateOfBirth: parsedDateOfBirth,
                phoneNumber,
                email,
                company,
               
                driversLicense,
              
                licenseExpiry: parsedLicenseExpiry,
                driverPhoto,
                address,
                fleetManagerId,
            });

            console.log("[SUCCESS] Driver added successfully.");
            res.status(201).json({ message: "Driver added successfully", driver: newDriver });
        });
    } catch (error) {
        console.error("[ERROR] Error adding driver:", error);
        res.status(500).json({ message: "Internal Server Error", error });
    }
};

export const getAllDrivers = async (req: Request, res: Response): Promise<void> => {
    try {
        const drivers = await Driver.findAll({ include: [{ model: User, as: "fleetManager" }] });
        res.status(200).json(drivers);
    } catch (error) {
        res.status(500).json({ error: "Error fetching drivers" });
    }
};

export const getDriverById = async (req: Request, res: Response): Promise<void> => {
    try {
        const driver = await Driver.findByPk(req.params.driverId, { include: [{ model: User, as: "fleetManager" }] });
        if (!driver) {
            res.status(404).json({ error: "Driver not found" });
            return;
        }
        res.status(200).json(driver);
    } catch (error) {
        res.status(500).json({ error: "Error fetching driver" });
    }
};

export const updateDriver = async (req: Request, res: Response): Promise<void> => {
    try {
        console.log("Update Request Body:", req.body);
        console.log("Driver ID:", req.params.driverId); // Log the driverId from the URL parameter

        if (!req.body.fleetManagerId) {
            res.status(400).json({ error: "fleetManagerId is required" });
            return;
        }

        const driver = await Driver.findByPk(req.params.driverId);
        if (!driver) {
            res.status(404).json({ error: "Driver not found" });
            return;
        }

        await driver.update(req.body);
        res.status(200).json(driver);
    } catch (error) {
        console.error("Error updating driver:", error);
        res.status(500).json({ error: "Error updating driver", details: error });
    }
};


export const deleteDriver = async (req: Request, res: Response): Promise<void> => {
    try {
        console.log("🚀 Received DELETE request for driver ID:", req.params.driverId);

        const driverId = req.params.driverId;
        console.log("🔍 Searching for driver with ID:", driverId);

        const driver = await Driver.findByPk(driverId);
        
        if (!driver) {
            console.log("❌ Driver not found:", driverId);
            res.status(404).json({ error: "Driver not found" });
            return;
        }

        console.log("✅ Driver found, proceeding to delete:", driverId);
        await driver.destroy();

        console.log("🗑️ Driver successfully deleted:", driverId);
        res.status(204).send();
    } catch (error) {
        console.error("❌ Error deleting driver:", error);
        res.status(500).json({ error: "Error deleting driver" });
    }
};

export const getDriversByFleetManager = async (req: Request, res: Response): Promise<void> => {
    try {
        const { fleetManagerId } = req.params;

        if (!fleetManagerId) {
            res.status(400).json({ error: "Fleet Manager ID is required" });
        }

        const drivers = await Driver.findAll({ where: { fleetManagerId } });

        if (!drivers.length) {
            res.status(404).json({ message: "No drivers found for this Fleet Manager" });
        }

        res.status(200).json(drivers);
    } catch (error) {
        console.error("Error fetching drivers:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};
