import { Request, Response } from "express";
import axios from "axios";
import Reservation from "../models/Reservation";

const AUTH_TOKEN = 'cmi982-8ed9eafbb37d73b4df106a35746918aa';

// Create two separate API clients
const reservationsClient = axios.create({
    baseURL: 'https://api.eu.evcms.net/v3/reservations/',
    headers: {
        'Authorization': `Token ${AUTH_TOKEN}`,
        'Content-Type': 'application/json'
    }
});

const paymentsClient = axios.create({
    baseURL: 'https://api.eu.evcms.net/v3/',
    headers: {
        'Authorization': `Token ${AUTH_TOKEN}`,
        'Content-Type': 'application/json'
    }
});

interface WalletPaymentResponse {
    id: string;
    reservation: string;
    wallet: string;
    reserve_now: boolean;
    amount: number;
    status: string;
    created_at: string;
    updated_at: string;
}

interface ReservationRequest {
    connector: string;
    duration: number;
    start_date_time: string;
    end_date_time: string;
    rate: number;
    user: string;
    fleetManagerId: string;
    OrderId: string;
    timezone: string;
}

interface ReservationResponse {
    id: string;
    ocpp_reservation_id: string;
    id_token: string;
    charger: string;
    connector: string;
    duration: number;
    start_date_time: string;
    end_date_time: string;
    rate: number;
    source_id: string;
    timezone: string;
    status: string;
    created_at: string;
    updated_at: string;
    expiry_datetime: string;
    fleetManagerId:number;
    OrderId: string
}

export const createReservation = async (req: Request, res: Response): Promise<void> => {
    try {
        const {
            connector,
            duration,
            start_date_time,
            end_date_time,
            rate,
            user,
            fleetManagerId,
            OrderId,
            timezone
        } = req.body;

        // Validate required fields
        if (!fleetManagerId || !OrderId) {
            res.status(400).json({ message: "fleetManagerId and OrderId are required" });
            return;
        }

        // Validate dates
        const startDateTime = new Date(start_date_time);
        const endDateTime = new Date(end_date_time);

        if (isNaN(startDateTime.getTime()) || isNaN(endDateTime.getTime())) {
            res.status(400).json({ message: "Invalid date format. Use YYYY-MM-DD HH:MM:SS" });
            return;
        }

        if (startDateTime >= endDateTime) {
            res.status(400).json({ message: "start_date_time must be before end_date_time" });
            return;
        }

        if (isNaN(rate)) {
            res.status(400).json({ message: "Invalid rate. Must be a valid number" });
            return;
        }

        // Create reservation
        const response = await reservationsClient.post<ReservationResponse>("", {
            connector,
            duration,
            start_date_time,
            end_date_time,
            rate,
            user,
            timezone
        });

        const responseData = response.data;

        // Store reservation in database
        const newReservation = await Reservation.create({
            id: responseData.id,
            ocpp_reservation_id: responseData.ocpp_reservation_id,
            id_token: responseData.id_token,
            charger: responseData.charger,
            connector: responseData.connector,
            timezone: responseData.timezone,
            status: responseData.status,
            duration: responseData.duration,
            start_date_time: new Date(responseData.start_date_time),
            end_date_time: new Date(responseData.end_date_time),
            rate: responseData.rate,
            created_at: new Date(responseData.created_at),
            updated_at: new Date(responseData.updated_at),
            expiry_datetime: new Date(responseData.expiry_datetime),
            source_id: responseData.source_id,
            fleetManagerId,
            OrderId
        });

        // Process payment
        try {
            const walletPaymentResponse = await paymentsClient.post<WalletPaymentResponse>("payments/wallet-payment/", {
                reservation: responseData.id,
                wallet: responseData.source_id,
                reserve_now: false
            });

            // Update reservation status

            // Return success response
            res.status(201).json({
                success: true,
                reservation: newReservation,
                payment: walletPaymentResponse.data
            });

        } catch (walletError) {
            console.error("Wallet payment failed:", walletError);
            
            // Attempt to cancel reservation if payment fails
            try {
                await reservationsClient.delete(`${responseData.id}`);
                await Reservation.destroy({ where: { id: responseData.id } });
            } catch (cancelError) {
                console.error("Failed to cancel reservation:", cancelError);
            }

            // Return error response
            const errorMessage = axios.isAxiosError(walletError) 
                ? walletError.response?.data?.message || walletError.message
                : 'Payment processing failed';
                
            res.status(402).json({
                success: false,
                message: "Reservation created but payment failed",
                error: errorMessage,
                reservation: newReservation
            });
        }

    } catch (error) {
        console.error("Error in createReservation:", error);
        
        if (axios.isAxiosError(error)) {
            const status = error.response?.status || 500;
            const errorData = error.response?.data || { message: error.message };
            res.status(status).json({
                success: false,
                message: "API request failed",
                error: errorData
            });
        } else if (error instanceof Error) {
            res.status(400).json({
                success: false,
                message: "Invalid request",
                error: error.message
            });
        } else {
            res.status(500).json({
                success: false,
                message: "Internal server error",
                error: "An unknown error occurred"
            });
        }
    }
};

// List Reservations
export const listReservations = async (req: Request, res: Response): Promise<void> => {
    try {
        const { start_date, end_date, status, customer_id, id, page, page_size } = req.query;

        const response = await reservationsClient.get("", {
            params: { 
                start_date, 
                end_date, 
                status, 
                customer_id, 
                id, 
                page, 
                page_size 
            },
        });

        res.status(200).json(response.data);
    } catch (error: any) {
        console.error("Error fetching reservations:", error);
        res.status(500).json({ 
            message: "Error fetching reservations", 
            error: error.message 
        });
    }
};

// Retrieve a Single Reservation
const formatDateForResponse = (date: Date): string => {
    return date.toISOString(); // Or use your preferred date format
};

export const getReservation = async (req: Request, res: Response): Promise<void> => {
    try {
        const { OrderId} = req.params;

        // Validate OrderId format (optional)
        if (!OrderId || typeof OrderId !== 'string') {
            res.status(400).json({ message: "OrderId is required and must be a string" });
            return;
        }

        // Find reservation in local database by OrderId
        const reservation = await Reservation.findOne({ 
            where: { OrderId} 
        });

        if (!reservation) {
            res.status(404).json({ 
                message: `Reservation with OrderId ${OrderId} not found` 
            });
            return;
        }

        // Convert Date objects to strings for response
        const response: ReservationResponse = {
            id: reservation.id,
            ocpp_reservation_id: reservation.ocpp_reservation_id,
            id_token: reservation.id_token,
            charger: reservation.charger,
            connector: reservation.connector,
            duration: reservation.duration,
            start_date_time: formatDateForResponse(reservation.start_date_time),
            end_date_time: formatDateForResponse(reservation.end_date_time),
            rate: reservation.rate,
            source_id: reservation.source_id,
            timezone: reservation.timezone,
            status: reservation.status,
            created_at: formatDateForResponse(reservation.created_at),
            updated_at: formatDateForResponse(reservation.updated_at),
            expiry_datetime: formatDateForResponse(reservation.expiry_datetime),
            fleetManagerId: reservation.fleetManagerId,
            OrderId: reservation.OrderId
        };

        res.status(200).json(response);
    } catch (error) {
        console.error("Error retrieving reservation:", error);
        res.status(500).json({ 
            message: "Internal server error", 
            error: error instanceof Error ? error.message : 'Unknown error' 
        });
    }
};

// Cancel (Delete) a Reservation
export const cancelReservation = async (req: Request, res: Response): Promise<void> => {
    try {
        const { id } = req.params;

        await reservationsClient.delete(`${id}/`);
        await Reservation.destroy({ where: { source_id: id } });

        res.status(204).send();
    } catch (error: any) {
        console.error("Error canceling reservation:", error);
        res.status(500).json({ 
            message: "Error canceling reservation", 
            error: error.message 
        });
    }
};
