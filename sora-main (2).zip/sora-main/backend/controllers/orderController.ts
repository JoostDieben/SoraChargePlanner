import { Request, Response } from 'express';
import Order from '../models/Order'; // Path to the Order model
import { Op } from 'sequelize';

// Create a new Order
export const createOrder = async (req: Request, res: Response): Promise<void> => {
    console.log('Received request to create a new order');
    
    try {
        const {
            name,
            quantity,
            route,
            startLocation,
            endLocation,
            customer,
            items,
            weight,
            startDateTime,
            endDateTime,
            tripType,
            type,
            operatingDays,
            fleetManagerId,
            driverId,
            vehicleId,
        } = req.body;

        console.log('Request body:', req.body);

        // Log the individual fields to ensure they are received correctly
        console.log('Extracted fields:');
        console.log('Name:', name);
        console.log('Quantity:', quantity);
        console.log('Route:', route);
        console.log('Start Location:', startLocation);
        console.log('End Location:', endLocation);
        console.log('Customer:', customer);
        console.log('Items:', items);
        console.log('Weight:', weight);
        console.log('Start Date Time:', startDateTime);
        console.log('End Date Time:', endDateTime);
        console.log('Trip Type:', tripType);
        console.log('Type:', type);
        console.log('Operating Days:', operatingDays);
        console.log('Fleet Manager ID:', fleetManagerId);
        console.log('Driver ID:', driverId);
        console.log('Vehicle ID:', vehicleId);

        // Check if items is an array and join it, otherwise default to empty string
        const itemsString = Array.isArray(items) ? items.join(',') : (typeof items === 'string' ? items : '');

        // Check if operatingDays is an array and join it, otherwise default to empty string
        const operatingDaysString = Array.isArray(operatingDays) 
        ? operatingDays.join(',') 
        : (typeof operatingDays === 'string' ? operatingDays : '');
      

        // Creating the new order
        console.log('Attempting to create a new order...');
        const newOrder = await Order.create({
            name,
            quantity,
            route,
            startLocation,
            endLocation,
            customer,
            items: itemsString, // Use the stringified version
            weight,
            startDateTime,
            endDateTime,
            tripType,
            type,
            operatingDays: operatingDaysString, // Use the stringified version
            fleetManagerId,
            driverId,
            vehicleId,
        });

        console.log('Order created successfully:', newOrder);

        // Respond with the created order
        res.status(201).json(newOrder);
    } catch (error) {
        console.error('Error occurred while creating the order:', error);
        res.status(500).json({ error: 'An error occurred while creating the order.' });
    }
};


// Get all Orders
export const getAllOrders = async (req: Request, res: Response): Promise<void> => {
    try {
        const orders = await Order.findAll({
            include: ['fleetManager', 'driver', 'vehicle'],
        });
        res.status(200).json(orders);
    } catch (error) {
        res.status(500).json({ error: 'An error occurred while fetching the orders.' });
    }
};

// Get a single Order by OrderId
export const getOrderById = async (req: Request, res: Response): Promise<void> => {
    const { orderId } = req.params;
    try {
        const order = await Order.findOne({
            where: { OrderId: orderId },
            include: ['fleetManager', 'driver', 'vehicle'],
        });

        if (!order) {
            res.status(404).json({ error: 'Order not found' });
            return;
        }

        res.status(200).json(order);
    } catch (error) {
        res.status(500).json({ error: 'An error occurred while fetching the order.' });
    }
};

// Update an Order
export const updateOrder = async (req: Request, res: Response): Promise<void> => {
    const { orderId } = req.params;
    const { name, quantity, route, startLocation, endLocation, customer, items, weight, startDateTime, endDateTime, tripType, type, operatingDays, fleetManagerId, driverId, vehicleId } = req.body;

    try {
        const order = await Order.findOne({ where: { OrderId: orderId } });

        if (!order) {
            res.status(404).json({ error: 'Order not found' });
            return;
        }

        await order.update({
            name,
            quantity,
            route,
            startLocation,
            endLocation,
            customer,
            items,
            weight,
            startDateTime,
            endDateTime,
            tripType,
            type,
            operatingDays,
            fleetManagerId,
            driverId,
            vehicleId,
        });

        res.status(200).json(order);
    } catch (error) {
        res.status(500).json({ error: 'An error occurred while updating the order.' });
    }
};

// Delete an Order
export const deleteOrder = async (req: Request, res: Response): Promise<void> => {
    const { orderId } = req.params;
    try {
        const order = await Order.findOne({ where: { OrderId: orderId } });

        if (!order) {
            res.status(404).json({ error: 'Order not found' });
            return;
        }

        await order.destroy();
        res.status(200).json({ message: 'Order deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: 'An error occurred while deleting the order.' });
    }
};

// Get Orders by a specific attribute (example: customer)
export const getOrdersByCustomer = async (req: Request, res: Response): Promise<void> => {
    const { customer } = req.params;
    try {
        const orders = await Order.findAll({
            where: {
                customer: {
                    [Op.iLike]: `%${customer}%`, // Case-insensitive search
                },
            },
            include: ['fleetManager', 'driver', 'vehicle'],
        });

        if (!orders.length) {
            res.status(404).json({ error: 'No orders found for this customer' });
            return;
        }

        res.status(200).json(orders);
    } catch (error) {
        res.status(500).json({ error: 'An error occurred while fetching orders by customer.' });
    }
};
