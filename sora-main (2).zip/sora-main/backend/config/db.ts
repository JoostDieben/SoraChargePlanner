import { Sequelize } from "sequelize";
import dotenv from "dotenv";

dotenv.config(); // ✅ Ensure dotenv is loaded

console.log("🔍 DB_USER:", process.env.DB_USER);
console.log("🔍 DB_PASS:", process.env.DB_PASS ? "Loaded" : "Not Loaded"); // Debug
console.log("🔍 DB_HOST:", process.env.DB_HOST);

const sequelize = new Sequelize(
  process.env.DB_NAME || "",
  process.env.DB_USER || "",
  process.env.DB_PASS || "", // 🔴 Fix: Use DB_PASS instead of DB_PASSWORD
  {
    host: process.env.DB_HOST || "localhost",
    dialect: "mysql",
    port: 3306,
    logging: console.log, // ✅ Enable logging to debug
  }
);

export default sequelize;
